<?php

use Illuminate\Database\Seeder;

class MessagesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('messages')->insert([
            [
                'sender_id' => 1,
                'receiver_id' => 2,
                'content' => 'Xin chào Tâm!',
                'read_at' => Carbon::now(),
                'deleted_at' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '01/08/2018'),
                'updated_at' => Carbon::now()
            ],
            [
                'sender_id' => 2,
                'receiver_id' => 1,
                'content' => 'Xin chào Bitmo!',
                'read_at' => null,
                'deleted_at' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '02/08/2018'),
                'updated_at' => Carbon::now()
            ],
            [
                'sender_id' => 1,
                'receiver_id' => 3,
                'content' => 'Xin chào Member!',
                'read_at' => Carbon::now(),
                'deleted_at' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '02/08/2018'),
                'updated_at' => Carbon::now()
            ],
            [
                'sender_id' => 3,
                'receiver_id' => 1,
                'content' => 'Xin chào hệ thống!',
                'read_at' => Carbon::now(),
                'deleted_at' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '03/08/2018'),
                'updated_at' => Carbon::now()
            ],
            [
                'sender_id' => 2,
                'receiver_id' => 3,
                'content' => 'Xin chào 3!',
                'read_at' => null,
                'deleted_at' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '02/08/2018'),
                'updated_at' => Carbon::now()
            ],
            [
                'sender_id' => 3,
                'receiver_id' => 2,
                'content' => 'Xin chào 2!',
                'read_at' => null,
                'deleted_at' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '04/08/2018'),
                'updated_at' => Carbon::now()
            ],
            [
                'sender_id' => 2,
                'receiver_id' => 1,
                'content' => 'Tôi là Tâm',
                'read_at' => null,
                'deleted_at' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '04/08/2018'),
                'updated_at' => Carbon::now()
            ],
            [
                'sender_id' => 2,
                'receiver_id' => 1,
                'content' => 'Tôi xin tư vấn mở tài khoản.',
                'read_at' => null,
                'deleted_at' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '05/08/2018'),
                'updated_at' => Carbon::now()
            ],
            [
                'sender_id' => 1,
                'receiver_id' => 3,
                'content' => 'Xin chào Member 2!',
                'read_at' => Carbon::now(),
                'deleted_at' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '07/08/2018'),
                'updated_at' => Carbon::now()
            ],
            [
                'sender_id' => 3,
                'receiver_id' => 1,
                'content' => 'Xin chào hệ thống 2!',
                'read_at' => null,
                'deleted_at' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '08/08/2018'),
                'updated_at' => Carbon::now()
            ]
        ]);
    }
}
