<?php

use Illuminate\Database\Seeder;

class NotificationsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('notifications')->insert([
            [
            	'id' => '56b49ce3-f279-4b9e-ac9b-63c2809fd7fd',
                'type' => 'App\Notifications\RegisteredUserNotification',
                'notifiable_type' => 'App\User',
                'notifiable_id' => 1,
                'data' => '{"sender_id":2}',
                'read_at' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ],
            [
            	'id' => '90088163-9bd0-4b0c-88c7-2a4a0ab65caa',
                'type' => 'App\Notifications\PayingMoneyNotification',
                'notifiable_type' => 'App\User',
                'notifiable_id' => 1,
                'data' => '{"sender_id":2, "money_transaction_id":1}',
                'read_at' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ],
            [
            	'id' => 'a0ca974a-9091-4d46-b869-c3a773099dc1',
                'type' => 'App\Notifications\WithdrawingMoneyNotification',
                'notifiable_type' => 'App\User',
                'notifiable_id' => 1,
                'data' => '{"sender_id":2, "money_transaction_id":3}',
                'read_at' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ],
            [
                'id' => 'a0ca974a-9091-4d46-b869-c3a773099dc2',
                'type' => 'App\Notifications\PaidMoneyNotification',
                'notifiable_type' => 'App\User',
                'notifiable_id' => 1,
                'data' => '{"sender_id":1, "money_transaction_id":2}',
                'read_at' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ],
            [
                'id' => 'a0ca974a-9091-4d46-b869-c3a773099dc3',
                'type' => 'App\Notifications\WithdrawedMoneyNotification',
                'notifiable_type' => 'App\User',
                'notifiable_id' => 1,
                'data' => '{"sender_id":2, "money_transaction_id":4}',
                'read_at' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ],
            [
                'id' => 'a0ca974a-9091-4d46-b869-c3a773099dc4',
                'type' => 'App\Notifications\PaidMoneyNotification',
                'notifiable_type' => 'App\User',
                'notifiable_id' => 2,
                'data' => '{"sender_id":1, "money_transaction_id":2}',
                'read_at' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ],
            [
                'id' => 'a0ca974a-9091-4d46-b869-c3a773099dc5',
                'type' => 'App\Notifications\WithdrawedMoneyNotification',
                'notifiable_type' => 'App\User',
                'notifiable_id' => 2,
                'data' => '{"sender_id":1, "money_transaction_id":4}',
                'read_at' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ]
        ]);
    }
}
