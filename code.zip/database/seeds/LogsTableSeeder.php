<?php

use Illuminate\Database\Seeder;

class LogsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('logs')->insert([
            [
                'type' => 1,
                'table' => 'contracts',
                'action' => 'dashboard::contracts.store',
                'is_error' => 0,
                'note' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '01/08/2018'),
                'modified_by' => 2,
            ],
            [
                'type' => 2,
                'table' => 'contracts',
                'action' => 'dashboard::contracts.update',
                'is_error' => 0,
                'note' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '25/07/2018'),
                'modified_by' => 2,
            ],
            [
                'type' => 3,
                'table' => 'contracts',
                'action' => 'dashboard::contracts.destroy',
                'is_error' => 0,
                'note' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '01/07/2018'),
                'modified_by' => 2,
            ],
            [
                'type' => 4,
                'table' => 'contracts',
                'action' => 'dashboard::contracts.destroy',
                'is_error' => 0,
                'note' => null,
                'created_at' => Carbon::createFromFormat('d/m/Y', '01/05/2018'),
                'modified_by' => 2,
            ]
        ]);
    }
}
