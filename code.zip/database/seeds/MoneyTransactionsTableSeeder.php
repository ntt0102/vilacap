<?php

use Illuminate\Database\Seeder;

class MoneyTransactionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('money_transactions')->insert([
            [
                'user_id' => 1,
                'type' => 2,
                'cost' => 3000000,
                'method' => 2,
                'confirmed_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/05/2018'),
                'confirmed_by' => 1,
                'created_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/01/2018'),
                'updated_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/01/2018'),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                'user_id' => 1,
                'type' => 1,
                'cost' => 2000000,
                'method' => 1,
                'confirmed_at' => null,
                'confirmed_by' => null,
                'created_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/01/2018'),
                'updated_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/01/2018'),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                'user_id' => 1,
                'type' => 1,
                'cost' => 2000000,
                'method' => 1,
                'confirmed_at' => null,
                'confirmed_by' => null,
                'created_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/01/2018'),
                'updated_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/01/2018'),
                'deleted_at' => Carbon::now(),
                'modified_by' => 1,
            ]
        ]);
    }
}
