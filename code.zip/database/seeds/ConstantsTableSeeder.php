<?php

use Illuminate\Database\Seeder;

class ConstantsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('constants')->insert([
            [
                // 1
                'name' => 'Trạng thái bản ghi',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 2
                'name' => 'Giới tính thành viên',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
                
            ],
            [
                // 3
                'name' => 'Loại hợp đồng',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 4
                'name' => 'Chu kỳ hợp đồng',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 5
                'name' => 'Thứ tự sắp xếp',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 6
                'name' => 'Sắp xếp hợp đồng',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 7
                'name' => 'Sắp xếp thành viên',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 8
                'name' => 'Mức hợp đồng đối tác',
                'value' => 100000000,
                'is_array' => 0,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 9
                'name' => 'Loại sự kiện nhật ký',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 10
                'name' => 'Chu kỳ thời gian',
                'value' => 2,
                'is_array' => 0,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 11
                'name' => 'Đơn vị thời gian',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 12
                'name' => 'Loại thông báo',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 13
                'name' => 'Trạng thái thông báo',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 14
                'name' => 'Bảng cơ sở dữ liệu',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 15
                'name' => 'Chức năng trang web',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 16
                'name' => 'Trạng thái tin nhắn',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 17
                'name' => 'Tên nhóm thành viên',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 18
                'name' => 'Loại giao dịch tiền',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 19
                'name' => 'Phương thức giao dịch tiền',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 20
                'name' => 'Trạng thái giao dịch tiền',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 21
                'name' => 'Sắp xếp giao dịch tiền',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                // 22
                'name' => 'Trạng thái giao dịch hợp đồng',
                'value' => 1,
                'is_array' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => 1,
            ]

        ]);
    }
}
