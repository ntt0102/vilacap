<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ContractsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('contracts')->insert([
            [
                'user_id' => 1,
                'type' => 2,
                'cost' => 2000000,
                'periods' => 1,
                'image' => '',
                'buyed_at' => Carbon::createFromFormat('d/m/Y', '01/01/2018'),
                'sold_at' => null,
                'created_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/01/2018'),
                'updated_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/01/2018'),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                'user_id' => 1,
                'type' => 1,
                'cost' => 1000000,
                'periods' => 1,
                'image' => '',
                'buyed_at' => Carbon::createFromFormat('d/m/Y', '01/01/2018'),
                'sold_at' => null,
                'created_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/01/2018'),
                'updated_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/01/2018'),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                'user_id' => 1,
                'type' => 1,
                'cost' => 3000000,
                'periods' => 1,
                'image' => '',
                'buyed_at' => Carbon::createFromFormat('d/m/Y', '01/02/2018'),
                'sold_at' => Carbon::createFromFormat('d/m/Y', '05/01/2018'),
                'created_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/02/2018'),
                'updated_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/02/2018'),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                'user_id' => 1,
                'type' => 2,
                'cost' => 5000000,
                'periods' => 1,
                'image' => '',
                'buyed_at' => Carbon::createFromFormat('d/m/Y', '01/03/2017'),
                'sold_at' => Carbon::createFromFormat('d/m/Y', '01/01/2018'),
                'created_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/03/2017'),
                'updated_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/03/2017'),
                'deleted_at' => null,
                'modified_by' => 1,
            ],
            [
                'user_id' => 1,
                'type' => 2,
                'cost' => 7000000,
                'periods' => 1,
                'image' => '',
                'buyed_at' => Carbon::createFromFormat('d/m/Y', '01/03/2017'),
                'sold_at' => Carbon::createFromFormat('d/m/Y', '01/01/2018'),
                'created_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/03/2017'),
                'updated_at' => Carbon::createFromFormat('H:i d/m/Y', '09:00 01/03/2017'),
                'deleted_at' => Carbon::now(),
                'modified_by' => 1,
            ]
        ]);
    }
}
