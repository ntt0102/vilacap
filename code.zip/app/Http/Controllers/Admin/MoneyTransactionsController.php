<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Traits\Controllers\ResourceController;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Models\MoneyTransaction;
use App\Models\Classify;
use App\User;
use App\Notifications\PayingMoneyNotification; 
use App\Notifications\WithdrawingMoneyNotification; 
use App\Notifications\PaidMoneyNotification; 
use App\Notifications\WithdrawedMoneyNotification;
use Illuminate\Support\Facades\Notification;
use App\Utils;
use App\Models\Report;

class MoneyTransactionsController extends Controller
{
    use ResourceController;
    
    /**
     * @var string
     */
    protected $resourceAlias = 'admin.money_transactions';

    /**
     * @var string
     */
    protected $resourceRoutesAlias = 'admin::money_transactions';

    /**
     * Fully qualified class name
     *
     * @var string
     */
    protected $resourceModel = MoneyTransaction::class;

    /**
     * @var string
     */
    protected $resourceTitle = 'Giao dịch tiền';

    /**
     * @var string
     */
    protected $indexSubtitle = 'Lịch sử';

    /**
     * @var string
     */
    protected $editSubtitle = 'Sửa giao dịch';

    /**
     * @var string
     */
    protected $createSubtitle = 'Tạo giao dịch';

    /**
     * @var string
     */
    protected $listButtonIcon = '<i class="fas fa-history"></i>';

    /**
     * @var string
     */
    protected $createButtonIcon = '<i class="fas fa-exchange-alt"></i>';
    
    /**
     * Used to validate store.
     *
     * @return array
     */
    private function resourceStoreValidationData(Request $request = null)
    {
    	$withdrawal = $request->input('type', '') == 2;
        $rules['user_id'] = 'required';
    	$rules['type'] = 'required';
    	if($withdrawal) {
    		$assets = 5000000;
    		$rules['cost'] = 'required|numeric|min:1000000|max:'.$assets;
    	}
    	else {
	    	$rules['cost'] = 'required|numeric|min:1000000';
	    }
    	$rules['method'] = 'required';
    	//
        return [
            'rules' => $rules,
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * Used to validate update.
     *
     * @param $record
     * @return array
     */
    private function resourceUpdateValidationData($record, Request $request = null)
    {
        $withdrawal = $request->input('type', '') == 2;
        $rules['user_id'] = 'required';
    	$rules['type'] = 'required';
    	if($withdrawal) {
    		$assets = 5000000;
    		$rules['cost'] = 'required|numeric|min:1000000|max:'.$assets;
    	}
    	else {
	    	$rules['cost'] = 'required|numeric|min:1000000';
	    }
    	$rules['method'] = 'required';
    	//
        return [
            'rules' => $rules,
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param null $record
     * @return array
     */
    private function getValuesToSave(Request $request, $record = null)
    {
        $creating = is_null($record);
        $values = [];
        $values['user_id'] = $request->input('user_id', '');
        $values['type'] = $request->input('type', '');
        $values['cost'] = $request->input('cost', '');
        $values['method'] = $request->input('method', '');
        $values['modified_by'] = Auth::user()->id;

        return $values;
    }

    /**
     * @param $record
     */
    private function doStoreSuccess($record = null)
    {
        if($record){
            $users = User::where('is_admin', '=', 1)->whereNull('deleted_at')->get();
            //send notify
            switch ($record->type) {
			    case 1:
			        Notification::send($users, new PayingMoneyNotification($record));
			        break;
			    case 2:
			        Notification::send($users, new WithdrawingMoneyNotification($record));
			        break;
			}
        }
    }

    /**
     * Retrieve the list of the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $show
     * @param string|null $search
     * @return \Illuminate\Support\Collection
     */
    private function getSearchRecords(Request $request, $show = 15, $search = null)
    {
        $records = $this->getResourceModel()::leftjoin('users', 'users.id', '=', 'money_transactions.user_id');
        $records->leftjoin('users as modified', 'modified.id', '=', 'money_transactions.modified_by');
        $records->leftjoin('users as confirmed', 'confirmed.id', '=', 'money_transactions.confirmed_by');
        $records->leftjoin('classifies as type', function($join){
            $join->on('type.group', '=', DB::raw('18'));
            $join->on('type.sub_id', '=', 'money_transactions.type');
        });
        $records->leftjoin('classifies as method', function($join){
            $join->on('method.group', '=', DB::raw('19'));
            $join->on('method.value', '=', 'money_transactions.method');
        });
        $records->select('money_transactions.*',
            'users.name as user_name',
            'type.name as type_name',
            'method.name as method_name',
            DB::raw('(CASE WHEN money_transactions.confirmed_at IS NULL THEN NOW() ELSE money_transactions.confirmed_at END) AS confirmed_date'),
            DB::raw('SUBSTRING_INDEX(confirmed.name, " ", -1) AS confirmed_name'),
            DB::raw('SUBSTRING_INDEX(modified.name, " ", -1) AS modified_name'),
            DB::raw('(CASE WHEN money_transactions.deleted_at IS NULL THEN NOW() ELSE money_transactions.deleted_at END) AS deleted_date')
        );
        // Filter by Id
        $id = $request->input('id', '');
        if (! empty($id)) {
            $records->where('money_transactions.id', '=', $id);
        }
        // Filter by Search
        if (! empty($search)) {
            $records->where(function($query) use ($search){
                $query->orWhere('money_transactions.id', 'LIKE', '%'.$search.'%');
                $query->orWhere('money_transactions.cost', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.username', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.residence', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.phone', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.email', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('type.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('method.name', 'LIKE', '%'.$search.'%');
             });
        }
        // Filter by Contract Status
        $record_status = $request->input('record-status', '');
        if (! empty($record_status)) {
            if($record_status == 3)
                $records->whereNotNull('money_transactions.deleted_at');
            else {
                $records->whereNull('money_transactions.deleted_at');
                if($record_status == 1)
                    $records->whereNull('money_transactions.confirmed_at');
                if($record_status == 2)
                    $records->whereNotNull('money_transactions.confirmed_at');
            }
        }
        //
        // Order by
        $order_by = $request->input('order-by', '');
        if (! empty($order_by)) {
            list($_by, $_order) = explode("-", $order_by);
            // Order
            $order = Classify::where('group', '=', 5)->where('sub_id', '=', $_order)
                                ->whereNull('deleted_at')->get()->first();
            $order = $order ? $order->value : 'desc';
            // By
            $by = Classify::where('group', '=', 21)->where('sub_id', '=', $_by)
                                ->whereNull('deleted_at')->get()->first();
            $by = $by ? $by->value : 'contracts.id';
            // $by = $by->value;
        }
        else {
            $by = 'money_transactions.created_at';
            $order = 'desc';
        }
        $records->orderBy($by, $order);
        // $records->orderBy('money_transactions.created_at', 'desc');
        return $records->paginate($show);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    private function getFilterClassifies(Request $request = null)
    {
        $classifies['record_statuses'] = Classify::where('group', '=', 20)
                                                    ->whereNull('deleted_at')
                                                    ->orderBy('display_no', 'asc')->get();
        $classifies['bys'] = Classify::where('group', '=', 21)
                                                    ->whereNull('deleted_at')
                                                    ->orderBy('display_no', 'asc')->get();
        $classifies['orders'] = Classify::where('group', '=', 5)
                                                    ->whereNull('deleted_at')
                                                    ->orderBy('display_no', 'asc')->get();
        //
        if(! empty($request)){
            $classifies['record_status'] = $request->input('record-status');
            $classifies['order_by'] = $request->input('order-by');
        }
        return $classifies;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    private function getFormClassifies(Request $request = null)
    {
        $classifies['users'] = User::whereNull('deleted_at')
                                    ->orderBy('name', 'asc')->get();
        $classifies['types'] = Classify::where('group', '=', 18)
                                        ->whereNull('deleted_at')
                                        ->orderBy('display_no', 'asc')->get();
        $classifies['methods'] = Classify::where('group', '=', 19)
                                        ->whereNull('deleted_at')
                                        ->orderBy('display_no', 'asc')->get();
        if(! empty($request)){
            $classifies['user'] = $request->input('user');
        }   
        return $classifies;
    }

    /**
     * Confirm the Money Transaction.
     *
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function confirm(Request $request, $id)
    {
        $record = $this->getResourceModel()::findOrFail($id);
        $notification_id = $request->input('notification_id', '');

        $valuesToSave['modified_by'] = Auth::user()->id;
        if ($record->confirmed_at){
            if($notification_id){
                flash()->info('Đã được xác nhận bởi quản trị viên khác.');
            }
            else {
                $valuesToSave['confirmed_at'] = null;
                $title = 'Hủy xác nhận';
            }
            $type = 4;
        }
        else {
            $valuesToSave['confirmed_at'] = Carbon::now();
            $title = 'Xác nhận';
            $type = 2;
        }
        //
        if(! ($notification_id && $type == 4)){
            if ($record->update($valuesToSave)) {
                flash()->success($title.' thành công.');
                $is_error = 0;
                //
                if ($record->confirmed_at) {
                    //send notify
                    $user = User::find($record->user_id);
                    switch ($record->type) {
                        case 1:
                            Notification::send($user, new PaidMoneyNotification($record));
                            break;
                        case 2:
                            Notification::send($user, new WithdrawedMoneyNotification($record));
                            break;
                    }
                    //
                    // update assets
                    Utils::updateAssets($record->type, $record->user_id, (int)$record->cost);
                }
            } else {
                flash()->info($title.' thất bại.');
                $is_error = 1;
            }
            //
            $this->writeLog($type, $is_error);
        }
        //
        $urlParameter =  $request->input('classifies', '');
        if($notification_id){
            foreach (Auth::user()->unreadNotifications as $notification) {
                if($notification->id == $notification_id) {
                    $notification->markAsRead();
                }
            }
            return redirect($urlParameter);
        }
        return redirect(route($this->getResourceRoutesAlias().'.index').'?'.$urlParameter);
    }
}
