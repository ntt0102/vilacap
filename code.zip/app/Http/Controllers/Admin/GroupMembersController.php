<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\GroupMember;
use Illuminate\Support\Facades\DB;
use App\Models\Classify;
use App\User;
use Illuminate\Support\Facades\Auth;
use App\Utils;

class GroupMembersController extends Controller
{
    /**
     * Show the user's profile.
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $paginatorData = [];
        $show = (int) $request->input('show', '');
        $show = (is_numeric($show) && $show > 0 && $show <= 100) ? $show : 10;
        if ($show != 10) {
            $paginatorData['show'] = $show;
        }
        $search = trim($request->input('search', ''));
        if (! empty($search)) {
            $paginatorData['search'] = $search;
        }
        $records = $this->getSearchRecords($request, $show, $search);
        $records->appends($paginatorData);
        //
        $classifies = $this->getClassifies($request);

        return view('admin.group-members.index', compact('users', 'records', 'search', 'classifies'));
    }

    /**
     * Retrieve the list of the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $show
     * @param string|null $search
     * @return \Illuminate\Support\Collection
     */
    private function getSearchRecords(Request $request, $show = 15, $search = null)
    {
        $records = GroupMember::leftjoin('users as modified', 'modified.id', '=', 'group_members.modified_by');
        $records->leftjoin('users as members', 'members.id', '=', 'group_members.user_id');
        $records->select('group_members.*',
            'members.name as user_name',
            'members.username as user_username',
            'members.residence as user_residence',
            DB::raw('SUBSTRING_INDEX(modified.name, " ", -1) AS modified_name'),
            DB::raw('SUBSTRING_INDEX(members.name, " ", -1) AS _user_name')
        );
        // Filter by Search
        if (! empty($search)) {
            $records = $records->where(function($query) use ($search){
                $query->orWhere('members.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('members.username', 'LIKE', '%'.$search.'%');
                $query->orWhere('members.residence', 'LIKE', '%'.$search.'%');
             });
        }
        // Filter by Group Select
        $group = $request->input('group', '');
        $records = $records->where('group_members.group', '=', $group);
        //
        $records->orderBy('_user_name', 'asc');
        return $records->paginate($show);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    private function getClassifies(Request $request = null)
    {
        $classifies['groups'] = Classify::where('group', '=', 17)
                                                ->whereNull('deleted_at')
                                                ->orderBy('display_no', 'asc')->get();
        $users = User::select('users.id', 'users.name',
            DB::raw('SUBSTRING_INDEX(users.name, " ", -1) AS user_name')
        )->whereNull('users.deleted_at');
        //
        $group = $request->input('group', '');
        if($group){
            $groupMembers = GroupMember::where('group', '=', $group)->select('user_id')->get();
            $users = $users->whereNotIn('id', $groupMembers);
            if($group == 2) $users = $users->where('is_admin', '=', 1);
            if($group == 3) $users = $users->where('is_admin', '=', 0);
        }
        //
        $users = $users->orderBy('user_name', 'asc')->get();
        $classifies['users'] = $users;
        //
        if(! empty($request)){
            $classifies['group'] = $request->input('group', '');
        }
        return $classifies;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return Response
     */
    public function add(Request $request)
    {
        $group = $request->input('group', '');
        $userIds = $request->input('member', '');
        //
        $error = false;
        foreach ($userIds as $userId)
		{
	        $groupMember = GroupMember::create([
	            'group' => $group,
	            'user_id' => $userId,
	            'modified_by' => Auth::user()->id
	        ]);
	        $error = $error || empty($groupMember);
		}
        //
        if(!$error) flash()->success('Thêm thành viên thành công.');
        else flash()->info('Thêm thành viên thất bại.');
        //
        return redirect(route('admin::group-members', ['group' => $group]));
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return Response
     */
    public function destroy(Request $request, $id)
    {
        $record = GroupMember::findOrFail($id);
        if ($record->delete()) {
            flash()->success('Xóa thành viên thành công.');
            $is_error = 0;
        } else {
            flash()->info('Xóa thành viên thất bại.');
            $is_error = 1;
        }
        //
        Utils::writeLog(3, 'group_members', $is_error, 'Nhóm: '.$record->group.', Thành viên: '.$record->user_id);
        //
        $group = $request->input('group', '');
        return redirect(route('admin::group-members', ['group' => $group]));
    }
}
