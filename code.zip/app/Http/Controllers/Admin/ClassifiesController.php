<?php

namespace App\Http\Controllers\Admin;

use App\Models\Classify;
// use App\Utils;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Traits\Controllers\ResourceController;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use App\Models\Constant;
use App\User;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;

class ClassifiesController extends Controller
{
    use ResourceController;

    /**
     * @var string
     */
    protected $resourceAlias = 'admin.classifies';

    /**
     * @var string
     */
    protected $resourceRoutesAlias = 'admin::classifies';

    /**
     * Fully qualified class name
     *
     * @var string
     */
    protected $resourceModel = Classify::class;

    /**
     * @var string
     */
    protected $resourceTitle = 'Danh mục';

    /**
     * Used to validate store.
     *
     * @return array
     */
    private function resourceStoreValidationData(Request $request = null)
    {
        return [
            'rules' => [
                'group' => 'required|numeric',
                'value' => 'string|max:191',
                'name' => 'required|string|max:191',
                'display_no' => 'required|numeric|min:1',
                'sub_id' => 'required|numeric|min:1',
                'display_no' => Rule::unique('classifies')->where(function ($query) use ($request) {
                    $query->where('group', $request->group);
                }),
                'sub_id' => Rule::unique('classifies')->where(function ($query) use ($request) {
                    $query->where('group', $request->group);
                }),
            ],
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * Used to validate update.
     *
     * @param $record
     * @return array
     */
    private function resourceUpdateValidationData($record, Request $request = null)
    {
        return [
            'rules' => [
                'group' => 'required|numeric',
                'value' => 'string|max:191',
                'name' => 'required|string|max:191',
                'display_no' => 'required|numeric|min:1',
                'sub_id' => 'required|numeric|min:1',
                'display_no' => Rule::unique('classifies')->ignore($record->id)->where(function ($query) use($record){
                    $query->where('group', $record->group);
                }),
                'sub_id' => Rule::unique('classifies')->ignore($record->id)->where(function ($query) use($record){
                    $query->where('group', $record->group);
                })
            ],
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param null $record
     * @return array
     */
    private function getValuesToSave(Request $request, $record = null)
    {
        $creating = is_null($record);
        $values = [];
        $values['group'] = $request->input('group', '');
        $values['sub_id'] = $request->input('sub_id', '');
        $values['value'] = $request->input('value', '');
        $values['name'] = $request->input('name', '');
        $values['display_no'] = $request->input('display_no', '');
        $values['modified_by'] = Auth::user()->id;

        return $values;
    }

    /**
     * Retrieve the list of the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $show
     * @param string|null $search
     * @return \Illuminate\Support\Collection
     */
    private function getSearchRecords(Request $request, $show = 15, $search = null)
    {
        $records = $this->getResourceModel()::where('classifies.id', '>', 0);
        $group = $request->input('group', '');
        $record_status = $request->input('record-status', '');
        // Filter by Search
        if (! empty($search)) {
            $records = $records->where(function($query) use ($search){
                $query->orWhere('classifies.id', 'LIKE', '%'.$search.'%');
                $query->orWhere('classifies.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('classifies.value', 'LIKE', '%'.$search.'%');
             });
        }
        // Filter by Record Status Select
        if (! empty($record_status)) {
            $default_record_status = get_default_record_status();

            if($record_status == $default_record_status)
                $records = $records->whereNull('classifies.deleted_at');
            if($record_status && $record_status != $default_record_status)
                $records = $records->whereNotNull('classifies.deleted_at');
        }
        // Filter by Group Select
        if (! empty($group)) {
            $records = $records->where('classifies.group', 'LIKE', '%'.$group.'%');
        }
        //
        return $records->leftjoin('constants', 'constants.id', '=', 'classifies.group')
                        ->leftjoin('users as modified', 'modified.id', '=', 'classifies.modified_by')
                        ->select('classifies.*',
                            'constants.name as group_name',
                            DB::raw('SUBSTRING_INDEX(modified.name, " ", -1) AS modified_name')
                        )
                        ->orderBy('constants.name', 'asc')
                        ->orderBy('classifies.display_no', 'asc')
                        ->paginate($show);
    }
    
    /**
     * @param \Illuminate\Http\Request $request
     * @param array $classifies
     * @return array
     */
    private function getFilterClassifies(Request $request = null)
    {
        $classifies['record_statuses'] = Classify::where('group', '=', 1)
                                                ->where('sub_id', '<', 3)
                                                ->whereNull('deleted_at')
                                                ->orderBy('display_no', 'asc')->get();
        $classifies['groups'] = Constant::whereNull('deleted_at')->orderBy('name', 'asc')->get();
        //
        if(! empty($request)){
            $classifies['record_status'] = $request->input('record-status');
            $classifies['group'] = $request->input('group');
        }
        return $classifies;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param array $classifies
     * @return array
     */
    private function getFormClassifies(Request $request = null)
    {
        $classifies['groups'] = Constant::whereNull('deleted_at')->orderBy('name', 'asc')->get();
        //
        if(! empty($request)){
            $classifies['group'] = $request->input('group');
        }
        return $classifies;
    }

}
