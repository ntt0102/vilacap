<?php

namespace App\Http\Controllers\Admin;

use App\User;
use App\Models\Classify;
use App\Utils;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Traits\Controllers\ResourceController;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use PDF;
use View;

class UsersController extends Controller
{
    use ResourceController;

    /**
     * @var string
     */
    protected $resourceAlias = 'admin.users';

    /**
     * @var string
     */
    protected $resourceRoutesAlias = 'admin::users';

    /**
     * Fully qualified class name
     *
     * @var string
     */
    protected $resourceModel = User::class;

    /**
     * @var string
     */
    protected $resourceTitle = 'Thành viên';

    /**
     * @var string
     */
    protected $listButtonIcon = '<i class="fas fa-list-alt"></i>';

    /**
     * @var string
     */
    protected $createButtonIcon = '<i class="fas fa-user-plus"></i>';

    /**
     * Used to validate store.
     *
     * @return array
     */
    private function resourceStoreValidationData(Request $request = null)
    {
        return [
            'rules' => [
                'name' => 'required|string|max:191',
                'username' => 'required|numeric|digits:9|unique:users,username',
                'password' => 'nullable|string|min:6|max:32|confirmed',
                'gender' => 'required',
                'birthday' => 'required',
                'residence' => 'required|string|max:191',
                'phone' => 'required|numeric',
                'email' => 'required|email|unique:users,email',
            ],
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * Used to validate update.
     *
     * @param $record
     * @return array
     */
    private function resourceUpdateValidationData($record, Request $request = null)
    {
        return [
            'rules' => [
                'name' => 'required|string|max:191',
                'username' => 'required|numeric|digits:9|unique:users,username,'.$record->id,
                'password' => 'nullable|string|min:6|max:32|confirmed',
                'gender' => 'required',
                'birthday' => 'required',
                'residence' => 'required|string|max:191',
                'phone' => 'required|numeric',
                'email' => 'required|email|unique:users,email,'.$record->id,
            ],
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param null $record
     * @return array
     */
    private function getValuesToSave(Request $request, $record = null)
    {
        $creating = is_null($record);
        $values = [];
        $values['name'] = $request->input('name', '');
        $values['username'] = $request->input('username', '');
        $values['gender'] = $request->input('gender', '');
        $values['birthday'] = Carbon::createFromFormat('d/m/Y', $request->input('birthday', '' ));
        $values['residence'] = $request->input('residence', '');
        $values['phone'] = $request->input('phone', '');
        $values['email'] = $request->input('email', '');
        $values['is_admin'] = $request->input('is_admin') ? 1 : 0;
        if ($record && Auth::user()->id == $record->id) {
            $values['is_admin'] = Auth::user()->is_admin;
        }
        if($creating || ($record->avatar == config('adminlte.avatar-male') || $record->avatar == config('adminlte.avatar-female'))){
            $male = Classify::where('group', '=', 2)->where('sub_id', '=', 1)->whereNull('deleted_at')->get()->first()->value;
            $values['avatar'] = $request->input('gender') == $male ? config('adminlte.avatar-male') : config('adminlte.avatar-female');
        }
        if($creating){
            $values['theme'] = config('adminlte.theme');
            $values['skin'] = config('adminlte.skin');
        }
        // If creating user or providing password.
        $password = $request->input('password', null);
        if ($creating || !empty($password)) {
            $values['password'] = $password;
        }
        $values['modified_by'] = Auth::user()->id;

        return $values;
    }

    private function alterValuesToSave(Request $request, $values)
    {
        if (array_key_exists('password', $values)) {
            if (!empty($values['password'])) {
                $values['password'] = Hash::make($values['password']);
            } else {
                unset($values['password']);
            }
        }

        return $values;
    }

    /**
     * @param $record
     */
    private function doStoreSuccess($record = null)
    {
        if($record){
            Utils::addGroupMember(1, $record->id);
            if($record->is_admin) Utils::addGroupMember(2, $record->id);
            else Utils::addGroupMember(3, $record->id);
        }
    }

    /**
     * @param $record
     */
    private function doUpdateSuccess($record = null)
    {
        if($record){
            Utils::addGroupMember(1, $record->id);
            if($record->is_admin) {
                Utils::destroyGroupMember(3, $record->id);
                Utils::addGroupMember(2, $record->id);
            }
            else {
                Utils::destroyGroupMember(2, $record->id);
                Utils::addGroupMember(3, $record->id);
            }
        }
    }

    /**
     * @param $record
     * @return bool
     */
    private function checkDestroy($record)
    {
        if (Auth::user()->id == $record->id) {
            flash()->error('Bạn không thể xóa chính mình.');

            return false;
        }
        else {
            if($record->deleted_at) {
                Utils::addGroupMember(1, $record->id);
                if($record->is_admin) Utils::addGroupMember(2, $record->id);
                else Utils::addGroupMember(3, $record->id);
            }
            else {
                Utils::destroyGroupMember(1, $record->id);
                if($record->is_admin) Utils::destroyGroupMember(2, $record->id);
                else Utils::destroyGroupMember(3, $record->id);
            }
            return true;
        }
    }

    /**
     * Retrieve the list of the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $show
     * @param string|null $search
     * @return \Illuminate\Support\Collection
     */
    private function getSearchRecords(Request $request, $show = 15, $search = null)
    {
        $records = $this->getResourceModel()::leftjoin('users as modified', 'modified.id', '=', 'users.modified_by');
        $records->leftjoin('classifies as gender', function($join){
            $join->on('gender.group', '=', DB::raw('2'));
            $join->on('gender.value', '=', 'users.gender');
        });
        $records->select('users.*',
            'gender.name as gender_name',
            DB::raw('SUBSTRING_INDEX(CASE WHEN modified.name IS NULL THEN users.name ELSE modified.name END, " ", -1) AS modified_name'),
            DB::raw('SUBSTRING_INDEX(users.name, " ", -1) AS first_name')
        );
        // Filter by Id
        $id = $request->input('id', '');
        if (! empty($id)) {
            $records->where('users.id', '=', $id);
        }
        // Filter by Search
        if (! empty($search)) {
            $records = $records->where(function($query) use ($search){
                $query->orWhere('users.id', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.username', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.residence', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.phone', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.email', 'LIKE', '%'.$search.'%');
                $query->orWhere('gender.name', 'LIKE', '%'.$search.'%');
             });
        }
        // Filter by Record Status Select
        $record_status = $request->input('record-status', '');
        if (! empty($record_status)) {
            $default_record_status = get_default_record_status();

            if($record_status == $default_record_status)
                $records = $records->whereNull('users.deleted_at');
            if($record_status && $record_status != $default_record_status)
                $records = $records->whereNotNull('users.deleted_at');
        }
        // Order by
        $order_by = $request->input('order-by', '');
        if (! empty($order_by)) {
            list($_by, $_order) = explode("-", $order_by);
            // Order
            $order = Classify::where('group', '=', 5)->where('sub_id', '=', $_order)
                                ->whereNull('deleted_at')->get()->first();
            $order = $order ? $order->value : 'desc';
            // By
            $by = Classify::where('group', '=', 7)->where('sub_id', '=', $_by)
                                ->whereNull('deleted_at')->get()->first();
            $by = $by ? $by->value : 'users.id';
            // $by = $by->value;
        }
        else {
            $by = 'users.id';
            $order = 'desc';
        }
        $records->orderBy($by, $order);
        //
        return $records->paginate($show);
    }
    
    /**
     * @param \Illuminate\Http\Request $request
     * @param array $classifies
     * @return array
     */
    private function getFilterClassifies(Request $request = null)
    {
        $classifies['record_statuses'] = Classify::where('group', '=', 1)
                                                ->where('sub_id', '<', 3)
                                                ->whereNull('deleted_at')
                                                ->orderBy('display_no', 'asc')->get();
        $classifies['bys'] = Classify::where('group', '=', 7)
                                                    ->whereNull('deleted_at')
                                                    ->orderBy('display_no', 'asc')->get();
        $classifies['orders'] = Classify::where('group', '=', 5)
                                                    ->whereNull('deleted_at')
                                                    ->orderBy('display_no', 'asc')->get();
        if(! empty($request)){
            $classifies['record_status'] = $request->input('record-status');
            $classifies['order_by'] = $request->input('order-by');
        }
        return $classifies;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param array $classifies
     * @return array
     */
    private function getFormClassifies(Request $request = null)
    {
        $classifies['genders'] = Classify::where('group', '=', 2)
                                        ->whereNull('deleted_at')
                                        ->orderBy('display_no', 'asc')->get();
        return $classifies;
    }
    
    /**
     * Update the user's avatar.
     *
     * @param  Request  $request
     * @return Response
     */
    public function updateAvatar(Request $request)
    {
        list(, $table) = explode("::", $this->getResourceRoutesAlias());
        $image = $request->input('image');
        list(, $image) = explode(';', $image);
        list(, $image)      = explode(',', $image);
        $image = base64_decode($image);
        //
        $imageName = time().'.png';
        $record = $this->getResourceModel()::findOrFail($request->input('id'));
        //
        if($record->avatar != config('adminlte.avatar-male') && $record->avatar != config('adminlte.avatar-female'))
            File::delete(public_path( 'uploads/avatar/'.$record->avatar));
        //
        if(File::put(public_path( 'uploads/avatar/'.$imageName), $image)){
            $updateValues['modified_by'] = Auth::user()->id;
            $updateValues['avatar'] = $imageName;

            if ($record->update($updateValues)){
                Utils::writeLog(2, $table, 0);
                return response()->json(array('msg'=> 'success', 'avatar' => $record->getAvatarPath()));
            }
        }
        //
        Utils::writeLog(2, $table, 1);
        return response()->json(array('msg'=> 'error'));
    }

    /**
     * Download PDF file of the user.
     *
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function downloadPDF($id){
        $user = User::where('users.id', '=', $id)
        ->leftjoin('classifies as gender', function($join)
            {
                $join->on('gender.group', '=', DB::raw('2'));
                $join->on('gender.value', '=', 'users.gender');
            })
            ->select('users.*',
                'gender.name as gender_name'
            )->get()->first();

        $view1 = View::make('pdfs.user', compact('user'))->render();
        $view2 = '';
        // $view2 = View::make('pdfs.user', compact('user'))->render();

        $pdf = PDF::setOptions([
            'logOutputFile' => storage_path('logs/log.htm'),
            'tempDir' => storage_path('logs/')
        ])
        // ->loadView('pdfs.user', compact('users'));
        ->loadHTML($view1 . $view2);
        $fileName = 'HopDong-'.($user->is_admin ? 'A' : 'M').'-'.str_pad($user->id, 5, '0', STR_PAD_LEFT).'_'.date("H-i_d-m-Y", time());
        return $pdf->download($fileName.'.pdf');
       // return view('pdfs.user', compact('user'));
    }
}
