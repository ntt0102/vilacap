<?php

namespace App\Http\Controllers\Dashboard;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Utils;
use Illuminate\Support\Facades\Route;
use App\Models\Setting;

class SettingsController extends Controller
{
    /**
     * Edit the user's settings.
     *
     * @param  Request  $request
     * @return Response
     */
    public function save(Request $request)
    {
        $user = Auth::user();
        $type = $request->input('type');
        $value = $request->input('value');
        //
        $setting = Setting::where('user_id', '=', $user->id)->where('type', '=', $type)->get()->first();
        //
        $error = 1;
        $actionType = 1;
        if($setting){
        	$actionType = 2;
        	if($setting->update(['value' => $value])) $error = 0;
        }
        else {
        	if(Setting::create(['user_id' => $user->id, 'type' => $type, 'value' => $value])) $error = 0;
        }
        //
        Utils::writeLog($actionType, 'settings', $error);
        return response()->json(array('msg'=> $error ? 'error' : 'success'));
    }
}