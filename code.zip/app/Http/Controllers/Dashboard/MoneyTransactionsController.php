<?php

namespace App\Http\Controllers\Dashboard;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Traits\Controllers\ResourceController;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Models\MoneyTransaction;
use App\Models\Classify;
use App\User;
use App\Notifications\PayingMoneyNotification; 
use App\Notifications\WithdrawingMoneyNotification; 
use Illuminate\Support\Facades\Notification;
use App\Utils;

class MoneyTransactionsController extends Controller
{
    use ResourceController;
    
    /**
     * @var string
     */
    protected $resourceAlias = 'dashboard.money_transactions';

    /**
     * @var string
     */
    protected $resourceRoutesAlias = 'dashboard::money_transactions';

    /**
     * Fully qualified class name
     *
     * @var string
     */
    protected $resourceModel = MoneyTransaction::class;

    /**
     * @var string
     */
    protected $resourceTitle = 'Giao dịch tiền';

    /**
     * @var string
     */
    protected $indexSubtitle = 'Lịch sử';

    /**
     * @var string
     */
    protected $editSubtitle = 'Sửa giao dịch';

    /**
     * @var string
     */
    protected $createSubtitle = 'Tạo giao dịch';

    /**
     * @var string
     */
    protected $listButtonIcon = '<i class="fas fa-history"></i>';

    /**
     * @var string
     */
    protected $createButtonIcon = '<i class="fas fa-exchange-alt"></i>';

    /**
     * Used to validate store.
     *
     * @return array
     */
    private function resourceStoreValidationData(Request $request = null)
    {
    	$withdrawal = $request->input('type', '') == 2;
    	$rules['type'] = 'required';
    	if($withdrawal) {
    		$assets = 5000000;
    		$rules['cost'] = 'required|numeric|min:1000000|max:'.$assets;
    	}
    	else {
	    	$rules['cost'] = 'required|numeric|min:1000000';
	    }
    	$rules['method'] = 'required';
    	//
        return [
            'rules' => $rules,
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * Used to validate update.
     *
     * @param $record
     * @return array
     */
    private function resourceUpdateValidationData($record, Request $request = null)
    {
        $withdrawal = $request->input('type', '') == 2;
    	$rules['type'] = 'required';
    	if($withdrawal) {
    		$assets = 5000000;
    		$rules['cost'] = 'required|numeric|min:1000000|max:'.$assets;
    	}
    	else {
	    	$rules['cost'] = 'required|numeric|min:1000000';
	    }
    	$rules['method'] = 'required';
    	//
        return [
            'rules' => $rules,
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param null $record
     * @return array
     */
    private function getValuesToSave(Request $request, $record = null)
    {
    	$user_id = Auth::user()->id;
        $creating = is_null($record);
        $values = [];
        if($creating) $values['user_id'] = $user_id;
        $values['type'] = $request->input('type', '');
        $values['cost'] = $request->input('cost', '');
        $values['method'] = $request->input('method', '');
        $values['modified_by'] = $user_id;

        return $values;
    }

    /**
     * @param $record
     */
    private function doStoreSuccess($record = null)
    {
        if($record){
            $users = User::where('is_admin', '=', 1)->whereNull('deleted_at')->get();
            //send notify
            switch ($record->type) {
			    case 1:
			        Notification::send($users, new PayingMoneyNotification($record));
			        break;
			    case 2:
			        Notification::send($users, new WithdrawingMoneyNotification($record));
			        break;
			}
        }
    }

    /**
     * @param $type
     * @param $is_error
     * @param $record
     */
    private function writeLog($type, $is_error, $record = null)
    {
        list(, $table) = explode("::", $this->getResourceRoutesAlias());
        $note = null;
        if($record) $note = $record->type == 1 ? 'Nộp tiền' : 'Rút tiền';
        else $note = $request->input('type') == 1 ? 'Nộp tiền' : 'Rút tiền';
        Utils::writeLog($type, $table, $is_error, $note);
    }

    /**
     * Retrieve the list of the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $show
     * @param string|null $search
     * @return \Illuminate\Support\Collection
     */
    private function getSearchRecords(Request $request, $show = 15, $search = null)
    {
        $records = $this->getResourceModel()::where('money_transactions.user_id', '=', Auth::user()->id);
        $records->leftjoin('users', 'users.id', '=', 'money_transactions.user_id');
        $records->leftjoin('classifies as type', function($join){
            $join->on('type.group', '=', DB::raw('18'));
            $join->on('type.sub_id', '=', 'money_transactions.type');
        });
        $records->leftjoin('classifies as method', function($join){
            $join->on('method.group', '=', DB::raw('19'));
            $join->on('method.value', '=', 'money_transactions.method');
        });
        $records->select('money_transactions.*',
            'users.name as user_name',
            'type.name as type_name',
            'method.name as method_name'
        );
        // Filter by Id
        $id = $request->input('id', '');
        if (! empty($id)) {
            $records->where('money_transactions.id', '=', $id);
        }
        // Filter by Search
        if (! empty($search)) {
            $records->where(function($query) use ($search){
                $query->orWhere('money_transactions.id', 'LIKE', '%'.$search.'%');
                $query->orWhere('money_transactions.cost', 'LIKE', '%'.$search.'%');
                $query->orWhere('type.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('method.name', 'LIKE', '%'.$search.'%');
             });
        }
        // Filter by Contract Status
        $record_status = $request->input('record-status', '');
        $records->whereNull('money_transactions.deleted_at');
        if (! empty($record_status)) {
            if($record_status == 1)
                $records->whereNull('money_transactions.confirmed_at');
            if($record_status == 2)
                $records->whereNotNull('money_transactions.confirmed_at');
        }
        //
        $records->orderBy('money_transactions.created_at', 'desc');
        return $records->paginate($show);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    private function getFilterClassifies(Request $request = null)
    {
        $classifies['record_statuses'] = Classify::where('group', '=', 20)
                                                    ->where('sub_id', '<', 3)
                                                    ->whereNull('deleted_at')
                                                    ->orderBy('display_no', 'asc')->get();
        //
        if(! empty($request)){
            $classifies['record_status'] = $request->input('record-status');
        }
        return $classifies;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    private function getFormClassifies(Request $request = null)
    {
        $classifies['types'] = Classify::where('group', '=', 18)
                                        ->whereNull('deleted_at')
                                        ->orderBy('display_no', 'asc')->get();
        $classifies['methods'] = Classify::where('group', '=', 19)
                                        ->whereNull('deleted_at')
                                        ->orderBy('display_no', 'asc')->get();
        return $classifies;
    }
}
