<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\Contract;
use App\Models\Classify;
use App\User;
use App\Models\Constant;
use App\Utils;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Traits\Controllers\ResourceController;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use PDF;
use View;
use App\Notifications\BuyedContractNotification; 
use App\Notifications\SoldContractNotification;
use Illuminate\Support\Facades\Notification;

class ContractsController extends Controller
{
    use ResourceController;
    
    /**
     * @var string
     */
    protected $resourceAlias = 'dashboard.contracts';

    /**
     * @var string
     */
    protected $resourceRoutesAlias = 'dashboard::contracts';

    /**
     * Fully qualified class name
     *
     * @var string
     */
    protected $resourceModel = Contract::class;

    /**
     * @var string
     */
    protected $resourceTitle = 'Giao dịch hợp đồng';

    /**
     * @var string
     */
    protected $createSubtitle = 'Mua hợp đồng';

    /**
     * @var string
     */
    protected $createButtonIcon = '<i class="fas fa-shopping-cart"></i>';

    /**
     * Used to validate store.
     *
     * @return array
     */
    private function resourceStoreValidationData(Request $request = null)
    {
        return [
            'rules' => [
                'cost' => 'required|numeric|min:1000000',
                'periods' => 'required',
            ],
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * Used to validate update.
     *
     * @param $record
     * @return array
     */
    private function resourceUpdateValidationData($record, Request $request = null)
    {
        return [
            'rules' => [
                'cost' => 'required|numeric|min:1000000',
                'periods' => 'required',
            ],
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param null $record
     * @return array
     */
    private function getValuesToSave(Request $request, $record = null)
    {

        $creating = is_null($record);
        $values = [];
        $values['user_id'] = Auth::user()->id;
        $values['buyed_at'] = Carbon::now();
        //
        $limit = Constant::where('id', '=', 8)->whereNull('deleted_at')->get()->first()->value;
        $values['type'] = $request->input('cost', '') < $limit ? 1 : 2;
        //
        $values['cost'] = $request->input('cost', '');
        $values['periods'] = $request->input('periods', '');
        $values['modified_by'] = Auth::user()->id;

        return $values;
    }

    /**
     * @param $record
     */
    private function doStoreSuccess($record = null)
    {
        if($record){
            $users = User::where('is_admin', '=', 1)->whereNull('deleted_at')->get();
            //send notify
            Notification::send($users, new BuyedContractNotification($record));
        }
    }

    /**
     * Retrieve the list of the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $show
     * @param string|null $search
     * @return \Illuminate\Support\Collection
     */
    private function getSearchRecords(Request $request, $show = 15, $search = null)
    {
        $records = $this->getResourceModel()::where('contracts.user_id', '=', Auth::user()->id);
        $records->leftjoin('users', 'users.id', '=', 'contracts.user_id');
        $records->leftjoin('users as modified', 'modified.id', '=', 'contracts.modified_by');
        $records->leftjoin('classifies as type', function($join){
            $join->on('type.group', '=', DB::raw('3'));
            $join->on('type.sub_id', '=', 'contracts.type');
        });
        $records->leftjoin('classifies as periods', function($join){
            $join->on('periods.group', '=', DB::raw('4'));
            $join->on('periods.value', '=', 'contracts.periods');
        });
        $records->select('contracts.*',
            'users.name as user_name',
            'type.name as type_name',
            'periods.name as periods_name',
            DB::raw('DATE_ADD(contracts.buyed_at, INTERVAL contracts.periods YEAR) AS due_date'),
            DB::raw('(CASE WHEN contracts.sold_at IS NULL THEN NOW() ELSE contracts.sold_at END) AS sold_date'),
            DB::raw('SUBSTRING_INDEX(modified.name, " ", -1) AS modified_name')
        );
        // Filter by Id
        $id = $request->input('id', '');
        if (! empty($id)) {
            $records->where('contracts.id', '=', $id);
        }
        // Filter by Search
        if (! empty($search)) {
            $records->where(function($query) use ($search){
                $query->orWhere('contracts.id', 'LIKE', '%'.$search.'%');
                $query->orWhere('contracts.cost', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.username', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.residence', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.phone', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.email', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('type.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('periods.name', 'LIKE', '%'.$search.'%');
             });
        }
        // Filter by Contract Status
        $record_status = $request->input('record-status', '');
        $records->whereNull('contracts.deleted_at');
        if (! empty($record_status)) {
            if($record_status == 2)
                $records->whereNotNull('contracts.sold_at');
            if($record_status == 1)
                $records->whereNull('contracts.sold_at');
        }
        //
        $records->orderBy('contracts.id', 'desc');
        return $records->paginate($show);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    private function getFilterClassifies(Request $request = null)
    {
        $classifies['record_statuses'] = Classify::where('group', '=', 22)
                                                    ->where('sub_id', '<', 3)
                                                    ->whereNull('deleted_at')
                                                    ->orderBy('display_no', 'asc')->get();
        //
        if(! empty($request)){
            $classifies['record_status'] = $request->input('record-status');
        }
        return $classifies;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    private function getFormClassifies(Request $request = null)
    {
        $classifies['users'] = User::whereNull('deleted_at')
                                    ->orderBy('name', 'asc')->get();
        $classifies['types'] = Classify::where('group', '=', 3)
                                        ->whereNull('deleted_at')
                                        ->orderBy('display_no', 'asc')->get();
        $classifies['periods'] = Classify::where('group', '=', 4)
                                        ->whereNull('deleted_at')
                                        ->orderBy('display_no', 'asc')->get();
        return $classifies;
    }

    /**
     * Close or Cancel the contract.
     *
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function sell(Request $request, $id)
    {
        $record = $this->getResourceModel()::findOrFail($id);
        if ($record->sold_at){
            flash()->info('Đã được bán bởi hệ thống.');
        }
        else {
            $valuesToSave['sold_at'] = Carbon::now();
            $valuesToSave['modified_by'] = Auth::user()->id;
            //
            if ($record->update($valuesToSave)) {
                flash()->success('Bán hợp đồng thành công.');
                $is_error = 0;
                //
                //send notify
                if ($record->sold_at) {
                    $users = User::where('is_admin', '=', 1)->whereNull('deleted_at')->get();
                    Notification::send($users, new SoldContractNotification($record));
                }
            } else {
                flash()->info('Bán hợp đồng thất bại.');
                $is_error = 1;
            }
            //
            $this->writeLog(2, $is_error);
        }
        //
        $urlParameter =  $request->input('classifies', '');
        return redirect(route($this->getResourceRoutesAlias().'.index').'?'.$urlParameter);
    }

    /**
     * Download PDF file of the contract.
     *
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function downloadPDF($id){
        $fileName = 'HopDongSo'.$id.'_'.date("H-i_d-m-Y", time());
        $contract = $this->getResourceModel()::where('contracts.id', '=', $id)
        ->leftjoin('users', 'users.id', '=', 'contracts.user_id')
        ->leftjoin('classifies as type', function($join)
            {
                $join->on('type.group', '=', DB::raw('3'));
                $join->on('type.sub_id', '=', 'contracts.type');
            })
        ->leftjoin('classifies as periods', function($join)
            {
                $join->on('periods.group', '=', DB::raw('4'));
                $join->on('periods.value', '=', 'contracts.periods');
            })
        ->select('contracts.*',
            'users.name as user_name',
            'users.residence as user_residence',
            'users.phone as user_phone',
            'users.email as user_email',
            'type.name as type_name',
            'type.value as type_value',
            'periods.name as periods_name',
            DB::raw('DATE_ADD(contracts.buyed_at, INTERVAL contracts.periods YEAR) AS due_date')
        )->get()->first();

        $view1 = View::make('pdfs.contract', compact('contract'))->render();
        // $view2 = View::make('pdfs.contract', compact('contract'))->render();

        $pdf = PDF::setOptions([
            'logOutputFile' => storage_path('logs/log.htm'),
            'tempDir' => storage_path('logs/')
        ])
        ->loadView('pdfs.contract', compact('contract'));
        // ->loadHTML($view1 . $view2);
        return $pdf->download($fileName.'.pdf');
       // return view('pdfs.contract', compact('contract'));

    }
}
