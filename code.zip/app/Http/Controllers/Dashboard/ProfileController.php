<?php

namespace App\Http\Controllers\Dashboard;

use App\Utils;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Route;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use App\Models\Classify;
use PDF;
use View;
use App\User;
use Illuminate\Support\Facades\DB;

class ProfileController extends Controller
{
    /**
     * Show the user's profile.
     *
     * @return Response
     */
    public function showProfile()
    {
        $classifies['genders'] = Classify::where('group', '=', 2)
                                        ->whereNull('deleted_at')
                                        ->orderBy('display_no', 'asc')->get();
        return view('dashboard.profile.index', ['classifies' => $classifies]);
    }

    /**
     * Edit the user's profile.
     *
     * @param  Request  $request
     * @return Response
     */
    public function updateProfile(Request $request)
    {
        $user = Auth::user();

        $this->validate($request, [
            'name' => 'required|string|max:191',
            'username' => 'required|numeric|digits:9|unique:users,username,'.$user->id,
            'password' => 'nullable|string|min:6|max:32|confirmed',
            'gender' => 'required',
            'birthday' => 'required',
            'residence' => 'required|string|max:191',
            'phone' => 'required|numeric',
            'email' => 'required|email|unique:users,email,'.$user->id,
        ]);
        
        $updateValues = [
            'name' => $request->input('name', $user->name),
            'username' => $request->input('username', $user->username),
            'gender' => $request->input('gender', $user->gender),
            'birthday' => Carbon::createFromFormat('d/m/Y', $request->input('birthday', Carbon::parse(Carbon::createFromFormat('Y-m-d', $user->birthday))->format('d/m/Y') )),
            'residence' => $request->input('residence', $user->residence),
            'phone' => $request->input('phone', $user->phone),
            'email' => $request->input('email', $user->email),
        ];
        $password = $request->input('password', null);
        if (!empty($password)) {
            $updateValues['password'] = Hash::make($password);
        }
        if($user->avatar == config('adminlte.avatar-male') || $user->avatar == config('adminlte.avatar-female')){
            $male = Classify::where('group', '=', 2)->where('sub_id', '=', 1)->whereNull('deleted_at')->get()->first()->value;
            $updateValues['avatar'] = $request->input('gender') == $male ? config('adminlte.avatar-male') : config('adminlte.avatar-female');
        }
        $updateValues['modified_by'] = Auth::user()->id;
        if ($user->update($updateValues)) {
            flash()->success('Cập nhật thành công.');
            $is_error = 0;
        } else {
            flash()->info('Cập nhật thất bại.');
            $is_error = 1;
        }
        //
        Utils::writeLog(2, 'users', $is_error);

        return redirect(route('dashboard::profile'));
    }

    /**
     * Update the user's avatar.
     *
     * @param  Request  $request
     * @return Response
     */
    public function updateAvatar(Request $request)
    {
        $image = $request->input('image');
        list(, $image) = explode(';', $image);
        list(, $image)      = explode(',', $image);
        $image = base64_decode($image);
        //
        $imageName = time().'.png';
        $user = Auth::user();
        //
        if($user->avatar != config('adminlte.avatar-male') && $user->avatar != config('adminlte.avatar-female'))
            File::delete(public_path( 'uploads/avatar/'.$user->avatar));
        //
        if(File::put(public_path( 'uploads/avatar/'.$imageName), $image)){
            $updateValues = [
                'avatar' => $imageName
            ];
            $updateValues['modified_by'] = Auth::user()->id;
            if ($user->update($updateValues)){
                Utils::writeLog(2, 'users', 0);
                return response()->json(array('msg'=> 'success', 'avatar' => Auth::user()->getAvatarPath()));
            }
        }
        //
        Utils::writeLog(2, 'users', 1);
        return response()->json(array('msg'=> 'error'));
    }

    /**
     * Download PDF file of the user.
     *
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function downloadPDF(){
        $id = Auth::user()->id;
        $user = User::where('users.id', '=', $id)
        ->leftjoin('classifies as gender', function($join)
            {
                $join->on('gender.group', '=', DB::raw('2'));
                $join->on('gender.value', '=', 'users.gender');
            })
            ->select('users.*',
                'gender.name as gender_name'
            )->get()->first();

        $view1 = View::make('pdfs.user', compact('user'))->render();
        $view2 = '';
        // $view2 = View::make('pdfs.user', compact('user'))->render();

        $pdf = PDF::setOptions([
            'logOutputFile' => storage_path('logs/log.htm'),
            'tempDir' => storage_path('logs/')
        ])
        // ->loadView('pdfs.user', compact('users'));
        ->loadHTML($view1 . $view2);
        $fileName = 'HopDong-'.($user->is_admin ? 'A' : 'M').'-'.str_pad($user->id, 5, '0', STR_PAD_LEFT).'_'.date("H-i_d-m-Y", time());
        return $pdf->download($fileName.'.pdf');
       // return view('pdfs.user', compact('user'));

    }
}
