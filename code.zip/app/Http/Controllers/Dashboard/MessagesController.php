<?php

namespace App\Http\Controllers\Dashboard;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\User;
use Illuminate\Support\Facades\DB;
use App\Models\Message;
use Carbon\Carbon;
use App\Utils;
use App\Events\MessageSentEvent;
use App\Models\Classify;
use App\Models\GroupMember;
use OneSignal;

class MessagesController extends Controller
{
    /**
     * Show the messages.
     *
     * @param \Illuminate\Http\Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $group = $request->input('group', '');
        $inbox = $request->input('inbox', '');
        $user = Auth::user();
        //
        if(!$group) {
            $contacter_id = $request->input('id', '');
            $contacter = User::find($contacter_id);
            $this->_markAsRead($contacter_id, $user);
            $messages = $this->getMessages($contacter_id, $user);
        }
        else{
            $group = Classify::where('group', '=', 17)->where('sub_id', '=', $group)->whereNull('deleted_at')->get()->first();
            $messages = NULL;
            $contacter = NULL;
        }
        //
        $contacts = $this->getContacts($user);
        $groups = $this->getGroups($user);
        $inboxs = $this->getInbox($user, $inbox);
        //
        return view('dashboard.messages.index', compact('inbox', 'user', 'group', 'contacter' , 'contacts', 'inboxs', 'groups', 'messages'));
    }

    /**
     * @return array
     */
    private function getContacts($user)
    {
        $contacts = User::whereNull('deleted_at')->where('id', '<>', $user->id);

        if(! $user->is_admin) $contacts = $contacts->where('is_admin', '=', 1);

        $contacts = $contacts->orderBy('id', 'asc')->get();
        //
        return $contacts;
    }

    /**
     * @return array
     */
    private function getGroups($user)
    {
        if($user->is_admin)
            $groups = Classify::where('group', '=', 17)
                    ->whereNull('deleted_at')
                    ->orderBy('display_no', 'asc')->get();
        else $groups = NULL;
        //
        return $groups;
    }

    /**
     * @return array
     */
    private function getInbox($user, $inbox)
    {
        $sql =  "SELECT  a.*, d.name, d.avatar, b.unread_count ";
        $sql .= "FROM ( ";
        $sql .= "    SELECT *, (CASE WHEN sender_id = :user_id THEN receiver_id WHEN receiver_id = :user_id THEN sender_id ELSE NULL END) AS contacter_id ";
        $sql .= "    FROM messages  ";
        $sql .= "    WHERE (sender_id = :user_id OR receiver_id = :user_id) AND deleted_at IS NULL ";
        $sql .= ") a ";
        $sql .= "INNER JOIN ( ";
        $sql .= "    SELECT  c.contacter_id, MAX(c.created_at) mxdate, SUM(CASE WHEN c.read_at IS NULL AND c.receiver_id = :user_id THEN 1 ELSE 0 END) AS unread_count ";
        $sql .= "    FROM ( ";
        $sql .= "        SELECT *, (CASE WHEN sender_id = :user_id THEN receiver_id WHEN receiver_id = :user_id THEN sender_id ELSE NULL END) AS contacter_id ";
        $sql .= "        FROM messages  ";
        $sql .= "        WHERE (sender_id = :user_id OR receiver_id = :user_id) AND deleted_at IS NULL ";
        $sql .= "    ) c ";
        $sql .= "    GROUP BY c.contacter_id ";
        $sql .= ") b ON a.contacter_id = b.contacter_id AND a.created_at = b.mxdate ";
        $sql .= "LEFT JOIN users d ON d.id = a.contacter_id ";
        if($inbox) {
            $sql .= "WHERE d.name like  '%".$inbox."%' ";
            $sql .= "OR a.content like  '%".$inbox."%' ";
        }
        $sql .= "ORDER BY a.created_at DESC ";
        //
        $results = DB::select($sql, ['user_id' => $user->id]);
        return $results;
    }

    /**
     *
     * @param $contacter_id
     * @return array
     */
    private function getMessages($contacter_id, $user)
    {
        if (! empty($contacter_id)) {
            $sql =  "SELECT * ";
            $sql .= "FROM messages  ";
            $sql .= "WHERE ((sender_id = :user_id AND receiver_id = :contacter_id) OR (sender_id = :contacter_id AND receiver_id = :user_id)) ";
            $sql .= "AND deleted_at IS NULL ";
            $sql .= "ORDER BY created_at ASC ";
            //
            $results = DB::select($sql, ['user_id' => $user->id, 'contacter_id' => $contacter_id]);
            return $results;
        }
        else return NULL;
    }

    /**
     * @param $id
     */
    public function _markAsRead($sender_id, $user)
    {
        if (! empty($sender_id)) {
            Message::where('sender_id', $sender_id)->where('receiver_id', $user->id)->whereNull('read_at')->whereNull('deleted_at')
                ->update(array('read_at' => Carbon::now()));
        }
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param $id
     * @return Response
     */
    public function markAsRead(Request $request)
    {
        $contacterId = $request->input('contacterId', '');
        $this->_markAsRead($contacterId, Auth::user());
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return Response
     */
    public function save(Request $request)
    {
        $messageContent = $request->input('messageContent', '');
        $messageId = $request->input('messageId', '');
        $contacterId = $request->input('contacterId', '');
        $groupId = $request->input('groupId', '');
        $sender = Auth::user();
        //
        $response = [];
        $message = null;
        $actionType = null;
        $status = null;
        if($groupId){
            $groupMembers = GroupMember::leftjoin('users', 'users.id', '=', 'group_members.user_id')
            ->select('group_members.user_id',
                'users.name as user_name',
                DB::raw('CONCAT("'.asset('uploads/avatar').'/", users.avatar) as user_avatar')
            )
            ->where('group', '=', $groupId)->where('user_id', '<>', $sender->id)->get();
            $is_error = false;
            foreach ($groupMembers as $groupMember) {
                $message = Message::create([
                    'sender_id' => $sender->id,
                    'receiver_id' => $groupMember->user_id,
                    'content' => $messageContent
                ]);
                if($message) {
                    OneSignal::sendNotificationUsingTags(
                        $sender->name." đã gửi tin nhắn: ".$messageContent, 
                        array(["field" => "tag", "key" => "user_id", "relation" => "=", "value" => $groupMember->user_id]), 
                        $url = route('dashboard::messages', ['id' => $sender->id])
                    );
                    //
                    event(new MessageSentEvent($message, 1));
                }
                else $is_error = $is_error || true;
            }
            $status = $is_error ? 'error' : 'success';
            //
            $response['groupMembers'] = $groupMembers;
            $response['messageContent'] = $messageContent;
        }
        else {
            if($messageId) {
                $actionType = 2;
                $message = Message::findOrFail($messageId);
                $pre_content = $message->content;
                if($message->update(['content' => $messageContent])) $status = 'success';
                else $status = 'error';
                Utils::writeLog(2, 'messages', $status == 'error' ? 1 : 0, $pre_content.' -> '.$message->content);
                $latestMessageId = $request->input('latestMessageId', '');
            }
            else {
                $actionType = 1;
                $message = Message::create([
                    'sender_id' => $sender->id,
                    'receiver_id' => $contacterId,
                    'content' => $messageContent
                ]);
                if($message) {
                    OneSignal::sendNotificationUsingTags(
                        $sender->name." đã gửi tin nhắn: ".$messageContent, 
                        array(["field" => "tag", "key" => "user_id", "relation" => "=", "value" => $contacterId]), 
                        $url = route('dashboard::messages', ['id' => $sender->id])
                    );
                    //
                    $status = 'success';
                }
                else $status = 'error';
                $latestMessageId = NULL;
            }
            if($status == 'success') event(new MessageSentEvent($message, $actionType, $latestMessageId));
            //
            $response['actionType'] = $actionType;
            $response['messageId'] = $message->id;
        }
        $response['status'] = $status;
        $response['groupId'] = $groupId;
        //
        return response()->json($response);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return Response
     */
    public function destroy(Request $request)
    {
        $messageId = $request->input('messageId', '');
        $latestMessageId = $request->input('latestMessageId', '');
        $message = Message::findOrFail($messageId);
        $response['message_id'] = $messageId;
        $response['status'] = 'error';
        if($message){
            $content = $message->content;
            if ($message->update(['deleted_at' => Carbon::now()])) {
                $response['status'] = 'success';
                event(new MessageSentEvent($message, 3, $latestMessageId));
            }
            Utils::writeLog(3, 'messages', $response['status'] == 'error' ? 1 : 0, $content);
        }
        //
        return response()->json($response);
    }

    /**
     * Get interval unread messasages.
     *
     * @param  Request  $request
     * @return Response
     */
    public function getIntervals(Request $request)
    {
        $intervals = [];
        $messages = collect(Utils::getMessages());
        foreach ($messages as $message) {
            array_push($intervals, get_interval(Carbon::parse($message->created_at)));
        }
        //
        return response()->json($intervals);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return Response
     */
    public function getMessage(Request $request)
    {
        $messageId = $request->input('messageId', '');
        $isNewSender = $request->input('isNewSender', '');
        $actionType = $request->input('actionType', '');
        $message = Message::findOrFail($messageId);
        //
        $response['isNewSender'] = $isNewSender;
        $response['messageContent'] = $message->content;
        $response['senderId'] = $message->sender_id;
        $response['actionType'] = $actionType;
        // $response['messageTime'] = Carbon::parse($message->created_at)->diffInDays(Carbon::now()) > 1 ? date("d/m/Y", strtotime($message->created_at)) : date("H:i", strtotime($message->created_at));
        if($isNewSender == 1) {
            $sender = User::find($message->sender_id);
            $response['senderName'] = $sender->name;
            $response['senderAvatar'] = asset('uploads/avatar/'.$sender->avatar);
        }
        //
        return response()->json($response);
    }
}
