<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Carbon\Carbon;
use App\Utils;
use Illuminate\Support\Facades\Route;
use App\Models\Classify;
use App\Notifications\RegisteredUserNotification;
use Illuminate\Support\Facades\Notification;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|string|max:191',
            'username' => 'required|numeric|digits:9|unique:users,username',
            'password' => 'required|string|min:6|max:32|confirmed',
            'gender' => 'required',
            'birthday' => 'required',
            'residence' => 'required|string|max:191',
            'phone' => 'required|numeric',
            'email' => 'required|email|unique:users,email',
            'captcha' => 'required|captcha'
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        $male = Classify::where('group', '=', 2)->where('sub_id', '=', 1)->whereNull('deleted_at')->get()->first()->value;
        Utils::writeLog(1, 'users', 0);
        $user = User::create([
            'name' => $data['name'],
            'username' => $data['username'],
            'password' => Hash::make($data['password']),
            'gender' => $data['gender'],
            'birthday' => Carbon::createFromFormat('d/m/Y', $data['birthday']),
            'residence' => $data['residence'],
            'phone' => $data['phone'],
            'email' => $data['email'],
            'is_admin' => 0,
            'avatar' => $data['gender'] == $male ? config('adminlte.avatar-male') : config('adminlte.avatar-female'),
            'theme' => config('adminlte.theme'),
            'skin' => config('adminlte.skin'),
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ]);
        //
        // send notify
        $users = User::where('is_admin', '=', 1)->whereNull('deleted_at')->get();
        Notification::send($users, new RegisteredUserNotification($user));
        //
        // Add group member default
        Utils::addGroupMember(1, $user->id);
        Utils::addGroupMember(3, $user->id);
        //
        return $user;
    }

    /**
     * Refresh captcha code.
     *
     * @return json
     */
    public function refreshCaptcha()
    {
        return response()->json(['captcha'=> captcha_img()]);
    }
}
