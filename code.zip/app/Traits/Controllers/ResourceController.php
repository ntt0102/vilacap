<?php

namespace App\Traits\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Debugbar;
use Illuminate\Support\Facades\Route;

trait ResourceController
{
    use ResourceHelper;

    /**
     * Display a listing of the resource.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // $this->authorize('viewList', $this->getResourceModel());
        
        $paginatorData = [];
        $show = (int) $request->input('show', '');
        $show = (is_numeric($show) && $show > 0 && $show <= 100) ? $show : 10;
        if ($show != 10) {
            $paginatorData['show'] = $show;
        }
        $search = trim($request->input('search', ''));
        if (! empty($search)) {
            $paginatorData['search'] = $search;
        }
        $records = $this->getSearchRecords($request, $show, $search);
        $records->appends($paginatorData);
        //
        $classifies = $this->getFilterClassifies($request);

        // Debugbar::addMessage($records, 'mylabel');

        return view('_resources.index', $this->filterSearchViewData($request, [
            'records' => $records,
            'search' => $search,
            'resourceAlias' => $this->getResourceAlias(),
            'resourceRoutesAlias' => $this->getResourceRoutesAlias(),
            'resourceTitle' => $this->getResourceTitle(),
            'indexSubtitle' => $this->getIndexSubtitle(),
            'createButtonName' => $this->getCreateButtonName(),
            'classifies' => $classifies,
        ]));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        // $this->authorize('create', $this->getResourceModel());
        $classifies = $this->getFormClassifies($request);
        $class = $this->getResourceModel();
        return view('_resources.create', $this->filterCreateViewData([
            'record' => new $class(),
            'resourceAlias' => $this->getResourceAlias(),
            'resourceRoutesAlias' => $this->getResourceRoutesAlias(),
            'resourceTitle' => $this->getResourceTitle(),
            'createSubtitle' => $this->getCreateSubtitle(),
            'listButtonName' => $this->getListButtonName(),
            'classifies' => $classifies,
        ]));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        // $this->authorize('create', $this->getResourceModel());

        $valuesToSave = $this->getValuesToSave($request);
        $request->merge($valuesToSave);
        $this->resourceValidate($request, 'store');
        //
        $valuesToSave['modified_by'] = Auth::user()->id;
        //
        if ($record = $this->getResourceModel()::create($this->alterValuesToSave($request, $valuesToSave))) {
            flash()->success($this->getCreateSubtitle().' thành công.');
            $is_error = 0;
            // 
            $this->doStoreSuccess($record);
            // return $this->getRedirectAfterSave($record);
        } else {
            flash()->info($this->getCreateSubtitle().' thất bại.');
            $is_error = 1;
        }
        //
        $this->writeLog(1, $is_error, $record, $request);
        //
        $urlParameter =  $request->input('classifies', '');
        return redirect(route($this->getResourceRoutesAlias().'.index').'?'.$urlParameter);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    // public function show($id)
    // {
    //     return redirect(route($this->getResourceRoutesAlias().'.edit', $id));
    // }

    /**
     * Show the form for editing the specified resource.
     *
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|\Illuminate\View\View
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function edit(Request $request, $id)
    {
        $record = $this->getResourceModel()::findOrFail($id);

        // $this->authorize('update', $record);
        $classifies = $this->getFormClassifies($request);
        return view('_resources.edit', $this->filterEditViewData($record, [
            'record' => $record,
            'resourceAlias' => $this->getResourceAlias(),
            'resourceRoutesAlias' => $this->getResourceRoutesAlias(),
            'resourceTitle' => $this->getResourceTitle(),
            'editSubtitle' => $this->getEditSubtitle(),
            'listButtonName' => $this->getListButtonName(),
            'createButtonName' => $this->getCreateButtonName(),
            'classifies' => $classifies,
        ]));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id)
    {
        $record = $this->getResourceModel()::findOrFail($id);

        // $this->authorize('update', $record);

        $valuesToSave = $this->getValuesToSave($request, $record);
        $request->merge($valuesToSave);
        $this->resourceValidate($request, 'update', $record);
        //
        $valuesToSave['modified_by'] = Auth::user()->id;
        //
        if ($record->update($this->alterValuesToSave($request, $valuesToSave))) {
            flash()->success($this->getEditSubtitle().' thành công.');
            $is_error = 0;
            $this->doUpdateSuccess($record);
            // return $this->getRedirectAfterSave($record);
        } else {
            flash()->info($this->getEditSubtitle().' thất bại.');
            $is_error = 1;
        }
        //
        $this->writeLog(2, $is_error, $record, $request);

        $urlParameter =  $request->input('classifies', '');
        return redirect(route($this->getResourceRoutesAlias().'.index').'?'.$urlParameter);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function destroy(Request $request, $id)
    {
        $record = $this->getResourceModel()::findOrFail($id);

        // $this->authorize('delete', $record);
        $urlParameter =  $request->input('classifies', '');
        if (! $this->checkDestroy($record)) {
            return redirect(route($this->getResourceRoutesAlias().'.index').'?'.$urlParameter);
        }
        //
        $valuesToSave['modified_by'] = Auth::user()->id;
        if ($record->deleted_at){
            $valuesToSave['deleted_at'] = null;
            $title = 'Khôi phục';
            $type = 4;
        }
        else {
            $valuesToSave['deleted_at'] = Carbon::now();
            $title = 'Xóa';
            $type = 3;
        }
        //
        if ($record->update($valuesToSave)) {
            flash()->success($title.' thành công.');
            $is_error = 0;
        } else {
            flash()->info($title.' thất bại.');
            $is_error = 1;
        }
        //
        $this->writeLog($type, $is_error, $record, $request);

        return redirect(route($this->getResourceRoutesAlias().'.index').'?'.$urlParameter);
    }
}
