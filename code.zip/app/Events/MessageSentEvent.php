<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use App\Models\Message;
use App\User;
use Carbon\Carbon;
use App\Utils;

class MessageSentEvent implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $message;
    public $actionType;
    public $latestMessageId;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(Message $message, $actionType, $latestMessageId = NULL)
    {
        $this->message = $message;
        $this->actionType = $actionType;
        $this->latestMessageId = $latestMessageId;
    }

    /**
     * Get the data to broadcast.
     *
     * @return array
     */
    public function broadcastWith()
    {
        $response['actionType'] = $this->actionType;
        $response['messageId'] = $this->message->id;
        $response['messageContent'] = $this->message->content;
        $response['senderId'] = $this->message->sender_id;
        $response['latestMessageId'] = $this->latestMessageId;
        //
        return $response;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('Message.User.'.$this->message->receiver_id);
    }
}
