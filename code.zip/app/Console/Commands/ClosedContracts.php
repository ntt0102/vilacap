<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Carbon\Carbon;
use App\User;
use Illuminate\Support\Facades\DB;
use App\Notifications\ClosedContractNotification;
use Illuminate\Support\Facades\Notification;
use App\Models\Contract;

class ClosedContracts extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'closed:contracts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Close the contract at due date';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $sql = "SELECT * FROM ( ";
        $sql .= "    SELECT *, DATE_ADD(opened_at, INTERVAL periods YEAR) AS due_date FROM contracts ";
        $sql .= "    WHERE NOT open_confirmed_at IS NULL AND closed_at IS NULL AND deleted_at IS NULL ";
        $sql .= ") cts ";
        $sql .= "WHERE cts.due_date >= CURRENT_DATE ";
        //
        // $contracts = collect(DB::select($sql));
        $contracts = Contract::hydrate(DB::select($sql));
        foreach ($contracts as $contract) {

            if ($contract->update(['closed_at' => Carbon::now()])) {
                $users = User::where('is_admin', '=', 1)->whereNull('deleted_at')->get();
                Notification::send($users, new ClosedContractNotification($contract));
            }
        }
    }
}
