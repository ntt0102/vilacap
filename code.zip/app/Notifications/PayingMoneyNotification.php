<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use App\Models\MoneyTransaction;
use Illuminate\Notifications\Messages\BroadcastMessage;
use App\User;
use App\Models\Classify;
use OneSignal;

class PayingMoneyNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public $moneyTransaction;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(MoneyTransaction $moneyTransaction)
    {
        $this->moneyTransaction = $moneyTransaction;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', 'broadcast'];
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toDatabase($notifiable)
    {
        return [
            'sender_id' => $this->moneyTransaction->user_id,
            'money_transaction_id' => $this->moneyTransaction->id,
        ];
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toBroadcast($notifiable)
    {
        $user = User::find($this->moneyTransaction->user_id);
        $notifications_url = route('dashboard::notifications');
        $notifications_type = Classify::where('group', '=', 12)->where('sub_id', '=', 2)->whereNull('deleted_at')->get()->first()->name;
        //
        $this->toOneSignal($user, $notifications_url, $notifications_type);
        
        return new BroadcastMessage([
            'sender_id' => $user->id,
            'sender_name' => $user->name,
            'sender_avatar' => $user->avatar,
            'sender_is_admin' => $user->is_admin,
            'avatar_url' => asset('uploads'),
            'notifications_url' => $notifications_url,
            'notifications_type' => $notifications_type,
        ]);
    }

    /**
     * Send the notification to OneSignal.
     *
     * @param $user
     * @param $notifications_url
     * @param $notifications_type
     */
    public function toOneSignal($user, $notifications_url, $notifications_type)
    {
        OneSignal::sendNotificationUsingTags(
            $user->name.' '.mb_strtolower($notifications_type), 
            array(["field" => "tag", "key" => "is_admin", "relation" => "=", "value" => '1']), 
            $url = $notifications_url
        );
    }
}