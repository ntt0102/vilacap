<!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-{{ $theme }}-{{ $skin }} elevation-4">
    <!-- Brand Logo -->
    <a href="{{ route('welcome') }}" class="brand-link bg-{{ $skin }}">
      <i class="fab fa-bimobject brand-image elevation-5" style="font-size:35px; margin-left: 13px;"></i>
      <span class="brand-text font-weight-light">{!! config('adminlte.logo-name') !!}</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <a href="{{ route('dashboard::profile') }}">
            <img src="{{ Auth::user()->getAvatarPath() }}" class="img-circle elevation-2" alt="Ảnh đại diện">
          </a>
        </div>
        <div class="info">
          <a href="{{ route('dashboard::profile') }}" class="d-block">{{ Auth::user()->name }}</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="{{ route('dashboard::index') }}" class="nav-link {{ \App\Utils::checkRoute(['dashboard::index', 'admin::index']) ? 'active': '' }}">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>Tổng quan</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="{{ route('dashboard::profile') }}" class="nav-link {{ \App\Utils::checkRoute(['dashboard::profile']) ? 'active': '' }}">
              <i class="nav-icon fas fa-user-alt"></i>
              <p>Hồ sơ cá nhân</p>
            </a>
          </li>
          <li class="nav-item has-treeview {{ \App\Utils::checkRoute(['dashboard::money_transactions.index', 'dashboard::money_transactions.create', 'dashboard::money_transactions.edit']) ? 'menu-open': '' }}">
                <a class="nav-link load-none {{ \App\Utils::checkRoute(['dashboard::money_transactions.index', 'dashboard::money_transactions.create', 'dashboard::money_transactions.edit']) ? 'active': '' }}" href="#"> 
                    <i class="nav-icon fas fa-hand-holding-usd"></i>
                    <p>
                        Giao dịch tiền
                        <i class="right fa fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="{{ route('dashboard::money_transactions.create') }}" class="nav-link {{ \App\Utils::checkRoute(['dashboard::money_transactions.create']) ? 'active': '' }}">
                          <i class="fas fa-exchange-alt nav-icon"></i>
                          <p>Tạo giao dịch</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('dashboard::money_transactions.index', ['record-status' => get_default_record_status()]) }}" class="nav-link {{ \App\Utils::checkRoute(['dashboard::money_transactions.index', 'dashboard::money_transactions.edit']) ? 'active': '' }}">
                          <i class="fas fa-history nav-icon"></i>
                          <p>Lịch sử</p>
                        </a>
                    </li>
                </ul>
          </li>
          <li class="nav-item has-treeview {{ \App\Utils::checkRoute(['dashboard::contracts.index', 'dashboard::contracts.create', 'dashboard::contracts.edit']) ? 'menu-open': '' }}">
                <a class="nav-link load-none {{ \App\Utils::checkRoute(['dashboard::contracts.index', 'dashboard::contracts.create', 'dashboard::contracts.edit']) ? 'active': '' }}" href="#"> 
                    <i class="nav-icon fas fa-file-signature"></i>
                    <p>
                        Giao dịch hợp đồng
                        <i class="right fa fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="{{ route('dashboard::contracts.create') }}" class="nav-link {{ \App\Utils::checkRoute(['dashboard::contracts.create']) ? 'active': '' }}">
                          <i class="fas fa-shopping-cart nav-icon"></i>
                          <p>Mua hợp đồng</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('dashboard::contracts.index', ['record-status' => get_default_record_status()]) }}" class="nav-link {{ \App\Utils::checkRoute(['dashboard::contracts.index', 'dashboard::contracts.edit']) ? 'active': '' }}">
                          <i class="fas fa-list-ul nav-icon"></i>
                          <p>Danh sách</p>
                        </a>
                    </li>
                </ul>
          </li>
          <li class="nav-item">
            <a href="{{ route('dashboard::notifications') }}?status=1" class="nav-link {{ \App\Utils::checkRoute(['dashboard::notifications']) ? 'active': '' }}">
              <i class="nav-icon fas fa-bell"></i>
              <p>Thông báo</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="{{ route('dashboard::messages') }}" class="nav-link {{ \App\Utils::checkRoute(['dashboard::messages']) ? 'active': '' }}">
              <i class="nav-icon fas fa-comments"></i>
              <p>Tin nhắn</p>
            </a>
          </li>
          @if (Auth::user()->can('viewList', \App\User::class))
            <li class="nav-header">QUẢN LÝ</li>
            <li class="nav-item">
              <a href="{{ route('admin::group-members') }}" class="nav-link {{ \App\Utils::checkRoute(['admin::group-members']) ? 'active': '' }}">
                <i class="nav-icon fas fa-users"></i>
                <p>Nhóm thành viên</p>
              </a>
            </li>
            <li class="nav-item has-treeview {{ \App\Utils::checkRoute(['admin::users.index', 'admin::users.create', 'admin::users.edit']) ? 'menu-open': '' }}">
                <a class="nav-link load-none {{ \App\Utils::checkRoute(['admin::users.index', 'admin::users.create', 'admin::users.edit']) ? 'active': '' }}" href="#"> 
                    <i class="nav-icon fas fa-users-cog"></i>
                    <p>
                        Thành viên
                        <i class="right fa fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="{{ route('admin::users.index', ['record-status' => get_default_record_status()]) }}" class="nav-link {{ \App\Utils::checkRoute(['admin::users.index', 'admin::users.edit']) ? 'active': '' }}">
                          <i class="fas fa-list-alt nav-icon"></i>
                          <p>Danh sách</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('admin::users.create') }}" class="nav-link {{ \App\Utils::checkRoute(['admin::users.create']) ? 'active': '' }}">
                          <i class="fas fa-user-plus nav-icon"></i>
                          <p>Thêm mới</p>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item has-treeview {{ \App\Utils::checkRoute(['admin::money_transactions.index', 'admin::money_transactions.create', 'admin::money_transactions.edit']) ? 'menu-open': '' }}">
                <a class="nav-link load-none {{ \App\Utils::checkRoute(['admin::money_transactions.index', 'admin::money_transactions.create', 'admin::money_transactions.edit']) ? 'active': '' }}" href="#"> 
                    <i class="nav-icon fas fa-hand-holding-usd"></i>
                    <p>
                        Giao dịch tiền
                        <i class="right fa fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="{{ route('admin::money_transactions.index', ['record-status' => get_default_record_status()]) }}" class="nav-link {{ \App\Utils::checkRoute(['admin::money_transactions.index', 'admin::money_transactions.edit']) ? 'active': '' }}">
                          <i class="fas fa-history nav-icon"></i>
                          <p>Lịch sử</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('admin::money_transactions.create') }}" class="nav-link {{ \App\Utils::checkRoute(['admin::money_transactions.create']) ? 'active': '' }}">
                          <i class="fas fa-exchange-alt nav-icon"></i>
                          <p>Tạo giao dịch</p>
                        </a>
                    </li>
                </ul>
          </li>
            <li class="nav-item has-treeview {{ \App\Utils::checkRoute(['admin::contracts.index', 'admin::contracts.create', 'admin::contracts.edit']) ? 'menu-open': '' }}">
                <a class="nav-link load-none {{ \App\Utils::checkRoute(['admin::contracts.index', 'admin::contracts.create', 'admin::contracts.edit']) ? 'active': '' }}" href="#"> 
                    <i class="nav-icon fas fa-file-invoice-dollar"></i>
                    <p>
                        Giao dịch hợp đồng
                        <i class="right fa fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="{{ route('admin::contracts.index', ['record-status' => get_default_record_status()]) }}" class="nav-link {{ \App\Utils::checkRoute(['admin::contracts.index', 'admin::contracts.edit']) ? 'active': '' }}">
                          <i class="fas fa-list-ul nav-icon"></i>
                          <p>Danh sách</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('admin::contracts.create') }}" class="nav-link {{ \App\Utils::checkRoute(['admin::contracts.create']) ? 'active': '' }}">
                          <i class="fas fa-shopping-cart nav-icon"></i>
                          <p>Mua hợp đồng</p>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item has-treeview {{ \App\Utils::checkRoute(['admin::constants.index', 'admin::constants.create', 'admin::constants.edit']) ? 'menu-open': '' }}">
                <a class="nav-link load-none {{ \App\Utils::checkRoute(['admin::constants.index', 'admin::constants.create', 'admin::constants.edit']) ? 'active': '' }}" href="#"> 
                    <i class="nav-icon fab fa-adn"></i>
                    <p>
                        Định danh
                        <i class="right fa fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="{{ route('admin::constants.index', ['record-status' => get_default_record_status()]) }}" class="nav-link {{ \App\Utils::checkRoute(['admin::constants.index', 'admin::constants.edit']) ? 'active': '' }}">
                          <i class="fas fa-list-ul nav-icon"></i>
                          <p>Danh sách</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('admin::constants.create') }}" class="nav-link {{ \App\Utils::checkRoute(['admin::constants.create']) ? 'active': '' }}">
                          <i class="fas fa-plus nav-icon"></i>
                          <p>Tạo mới</p>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item has-treeview {{ \App\Utils::checkRoute(['admin::classifies.index', 'admin::classifies.create', 'admin::classifies.edit']) ? 'menu-open': '' }}">
                <a class="nav-link load-none {{ \App\Utils::checkRoute(['admin::classifies.index', 'admin::classifies.create', 'admin::classifies.edit']) ? 'active': '' }}" href="#"> 
                    <i class="nav-icon fas fa-list-ol"></i>
                    <p>
                        Danh mục
                        <i class="right fa fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="{{ route('admin::classifies.index', ['record-status' => get_default_record_status()]) }}" class="nav-link {{ \App\Utils::checkRoute(['admin::classifies.index', 'admin::classifies.edit']) ? 'active': '' }}">
                          <i class="fas fa-list-ul nav-icon"></i>
                          <p>Danh sách</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('admin::classifies.create') }}" class="nav-link {{ \App\Utils::checkRoute(['admin::classifies.create']) ? 'active': '' }}">
                          <i class="fas fa-plus nav-icon"></i>
                          <p>Tạo mới</p>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item">
              <a href="{{ route('admin::logs') }}?type=1&interval=1-2" class="nav-link {{ \App\Utils::checkRoute(['admin::logs']) ? 'active': '' }}">
                <i class="nav-icon fas fa-calendar-alt"></i>
                <p>Nhật ký</p>
              </a>
            </li>
          @endif
          <li class="nav-separator"></li>
          <li class="nav-item">
            <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
              <i class="nav-icon  fas fa-sign-out-alt"></i>
              <p>Đăng xuất</p>
            </a>

            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                {{ csrf_field() }}
            </form>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>