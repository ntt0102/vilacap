  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand bg-{{ $skin }} navbar-light fixed-top">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link load-none" href="#" data-widget="pushmenu"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li>
    </ul>
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      <?php
        $messages = \App\Utils::getMessages();
        $message_count = count($messages) > 0 ? $messages[0]->total : 0;
      ?>
      <!-- Message Dropdown Menu -->
      <li class="nav-item dropdown message" data-url="{{ route('dashboard::messages') }}" data-get-url="{{ route('dashboard::messages.getMessage') }}">
        <a class="nav-link load-none" data-toggle="dropdown" href="#" data-url="{{ route('dashboard::messages.getIntervals') }}">
          <i class="fas fa-comments"></i>
          <span class="badge badge-{{ $skin != 'warning' && $skin != 'danger' ? 'danger' : 'primary' }} navbar-badge {{ $message_count ? '' : 'hide' }}">{{ $message_count }}</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header text-muted"><span>{{ $message_count }}</span> tin nhắn</span>
          <div class="container">
            @includeIf('layouts.partials.backend.messages')
          </div>
          <div class="dropdown-divider"></div>
          <a href="{{ route('dashboard::messages') }}" class="dropdown-item dropdown-footer">Xem tất cả tin nhắn</a>
        </div>
        <div id='message'>
          <message></message>
        </div>
      </li>

      <?php
        $notifications = \App\Utils::getNotifications();
        $notification_count = count($notifications);
      ?>
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown notification">
        <a class="nav-link load-none" data-toggle="dropdown" href="#" data-url="{{ route('dashboard::notifications.getIntervals') }}">
          <i class="fas fa-bell"></i>
          <span class="badge badge-{{ $skin != 'warning' && $skin != 'danger' ? 'warning' : 'success' }} navbar-badge {{ $notification_count ? '' : 'hide' }}">{{ $notification_count }}</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header text-muted"><span>{{ $notification_count }}</span> thông báo</span>
          <div class="container">
            @includeIf('layouts.partials.backend.notifications')
          </div>
          <div class="dropdown-divider"></div>
          <a href="{{ route('dashboard::notifications', ['status' => 1]) }}" class="dropdown-item dropdown-footer">Xem tất cả thông báo</a>
        </div>
        <div id='notification'>
          <notification></notification>
        </div>
      </li>
      <li class="nav-item">
            <a class="nav-link load-none" href="#" data-widget="control-sidebar"><i class="fas fa-cog"></i></a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->
