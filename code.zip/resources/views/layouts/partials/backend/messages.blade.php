@if (count($messages))
  @foreach($messages as $message)
    <?php
      $sender = App\User::find($message->sender_id);
      $user = Auth::user();
      $sender_name = $sender->name;
      $message_time = Carbon::parse($message->created_at)->diffInDays(Carbon::now()) > 1 ? date("d/m/Y", strtotime($message->created_at)) : date("H:i", strtotime($message->created_at));
      $is_star = $sender->is_admin && $user->is_admin;
    ?>
    <a href="{{ route('dashboard::messages', ['id' => $message->sender_id]) }}" class="dropdown-item" data-sender-id="{{ $message->sender_id }}">
      <div class="media">
        <img src="{{ asset('uploads/avatar/'.$sender->avatar) }}" alt="Ảnh đại diện người gửi" class="img-size-50 mr-3 img-circle">
        <div class="media-body">
          <h3 class="dropdown-item-title">
            {{ $sender_name }}
          </h3>
          <p class="text-sm content">{{ $message->content }}</p>
          <p class="text-sm text-muted"><i class="fas fa-clock mr-1"></i> <span class="clock">{{ get_interval(Carbon::parse($message->created_at)) }}</span>
            <span class="float-right text-sm">
              <span title="Tin nhắn chưa đọc" class="badge badge-danger">{{ $message->unread_count }}</span>
            </span>
          </p>
        </div>
      </div>
    </a>
  @endforeach
@endif