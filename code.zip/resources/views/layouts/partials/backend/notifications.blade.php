@if (count($notifications))
  @foreach($notifications as $notification)
    <?php
      $data = json_decode($notification->data, true);
      $sender = App\User::find($data['sender_id']);
      $user = Auth::user();
      $sender_name = $user->is_admin ? $sender->name : 'Hệ thống Bitmo';
      $is_star = $sender->is_admin && $user->is_admin;
    ?>
    <a href="{{ route('dashboard::notifications') }}?id={{ $notification->notification_id }}" class="dropdown-item">
      <div class="media">
        <img src="{{ asset('uploads/'.($user->is_admin ? 'avatar/'.$sender->avatar : 'logo.png')) }}" alt="Ảnh đại diện người gửi" class="img-size-50 mr-3 img-circle">
        <div class="media-body">
          <h3 class="dropdown-item-title">
            {{ $sender_name }}
          </h3>
          <p class="text-sm">{{ $notification->type_name }}</p>
          <p class="text-sm text-muted"><i class="fas fa-clock mr-1"></i> <span class="clock">{{ get_interval($notification->created_at) }}</span>
            @if ($is_star)
              <span class="star float-right text-sm text-danger"><i class="fa fa-star"></i></span>
            @endif
          </p>
        </div>
      </div>
    </a>
  @endforeach
@endif