<!-- Main Header -->
<nav class="navbar navbar-expand-md navbar-light bg-{{ $skin }} fixed-top ">
  <!-- Logo -->
  <a href="{{ route('welcome') }}" class="mr-5">
    <i class="fab fa-bimobject brand-image elevation-5" style="font-size:35px;"></i>
    <span class="brand-text font-weight-light" style="font-size: 15pt;">{!! config('adminlte.logo-name') !!}</span>
  </a>

  <!-- Toggle Icon -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation" style="">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="navbarColor01">
    <!-- Left navbar links -->
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link">Home</a>
      </li>
      <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle load-none" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Manage
          </a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="#">Link 1</a>
            <a class="dropdown-item" href="#">Link 2</a>
            <a class="dropdown-item" href="#">Link 3</a>
          </div>
      </li>
    </ul>
    <!-- Right navbar links -->
    <ul class="navbar-nav navbar-right navbar-right-link">
      @guest
        @if (Route::has('login'))
          <li class="nav-item">
            <a class="nav-link" href="{{ route('login') }}">Đăng nhập</a>
          </li>
        @endif
        @if (Route::has('register'))
          <li class="nav-item">
            <a class="nav-link" href="{{ route('register') }}">Đăng ký</a>
          </li>
        @endif
      @else
        @if (Route::has('dashboard::index'))
          <li class="nav-item">
            <a class="nav-link" href="{{ route('dashboard::index') }}">Trang quản lý</a>
          </li>
        @endif
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle load-none" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="{{ Auth::user()->getAvatarPath() }}" alt="profile-photo" class="img-circle elevation-4" width="30px;" style="margin-top: -10px;">&nbsp;
            {{ Auth::user()->name }}
          </a>
          <div class="dropdown-menu mt-1" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
              Đăng xuất
            </a>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                {{ csrf_field() }}
            </form>
          </div>
        </li>
      @endguest
    </ul>
    <!-- ./navbar-right-->
  </div>
  <!-- ./navbar-collapse -->
</nav>


