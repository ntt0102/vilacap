<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="robots" content="noindex, nofollow, noarchive">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <meta name="user-id" content="{{ Auth::user()->id }}">
        <meta name="user-is-admin" content="{{ Auth::user()->is_admin }}">

        <title>{{ config('app.name', 'Laravel') }} @hasSection('page-title') | @yield('page-title') @endif</title>

        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
        <!-- Admin LTE -->
        <link rel="stylesheet" href="{{ asset('plugins/adminlte/adminlte.min.css') }}">
        <!-- Jquery Confirm -->
        <link rel="stylesheet" href="{{ asset('/plugins/jquery-confirm/jquery-confirm.css') }}">
        <!-- Google Font: Source Sans Pro -->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,400i,700" rel="stylesheet">
        <!-- Layout -->
        <link rel="stylesheet" href="{{ asset('/dist/common/common.css') }}">
        <link rel="stylesheet" href="{{ asset('/dist/layouts/backend.css') }}">

        @yield('head-extras')
    </head>

    <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
    <body class="hold-transition sidebar-mini">
        <!-- Loading -->
        <div id="loading" class="text-center text-{{ $skin }}">
            <i class="fas fa-cog fa-spin fa-4x"></i>
            <datalist class="ajax">
                <option>{{ route('dashboard::notifications.getIntervals') }}</option>
                <option>{{ route('dashboard::messages.getIntervals') }}</option>
                <option>{{ route('dashboard::messages.save') }}</option>
                <option>{{ route('dashboard::messages.destroy') }}</option>
                <option>{{ route('dashboard::messages.markAsRead') }}</option>
                <option>{{ route('dashboard::messages.getMessage') }}</option>
            </datalist>
        </div>
        
        <!-- Site wrapper -->
        <div class="wrapper disabled">
            <!-- Header -->
            @includeIf('layouts.partials.backend.header', ['theme' => $theme, 'skin' => $skin])
            <!-- Main Sidebar -->
            @includeIf('layouts.partials.backend.main-sidebar', ['theme' => $theme, 'skin' => $skin])

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper pt-5">
                <!-- Content Header (Page header) -->
                <div class="content-header">
                  <div class="container-fluid">
                    <div class="row mb-2">
                      <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            @yield('page-title')
                        </h1>
                      </div><!-- /.col -->
                      <div class="col-sm-6">
                        @yield('breadcrumbs')
                      </div><!-- /.col -->
                    </div><!-- /.row -->
                  </div><!-- /.container-fluid -->
                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <div class="content">
                  <div class="container-fluid">
                        @includeIf('flash::message')

                        @yield('content')
                  </div>
                  <!-- /.container-fluid -->
                </div>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->
            @includeIf('layouts.partials.backend.control-sidebar', ['theme' => $theme, 'skin' => $skin])
            <!-- Main Footer -->
            <footer class="main-footer">
                <!-- To the right -->
                <div class="float-right d-none d-sm-block-down">
                  Anything you want
                </div>
                <!-- Default to the left -->
                <strong>Copyright &copy; 2018 <!-- <a href="https://adminlte.io">AdminLTE.io</a> -->.</strong> All rights reserved.
            </footer>
        </div>
        <!-- ./wrapper -->

        <!-- REQUIRED SCRIPTS -->
        <!-- jQuery -->
        <script src="{{ asset('plugins/jquery/jquery.min.js') }}"></script>
        <!-- Bootstrap -->
        <script src="{{ asset('plugins/bootstrap/bootstrap.bundle.min.js') }}"></script>
        <!-- AdminLTE -->
        <script src="{{ asset('plugins/adminlte/adminlte.min.js') }}"></script>
        <!-- Jquery Confirm -->
        <script src="{{ asset('plugins/jquery-confirm/jquery-confirm.js') }}"></script>
        <!-- Pusher -->
        <script src="https://js.pusher.com/3.1/pusher.min.js"></script>
        <!-- Common -->
        <script src="{{ asset('dist/common/common.js') }}"></script>
        <script src="{{ asset('dist/layouts/backend.js') }}"></script>
        <script src="{{ asset('dist/layouts/echo.js') }}"></script>
        <script src="{{ asset('dist/layouts/notification.js') }}"></script>
        <script src="{{ asset('dist/layouts/message.js') }}"></script>

        <!-- OPTIONAL SCRIPTS -->
        <script src="{{ asset('dist/_partials/cookie/cookie.js') }}"></script>
        <script src="{{ asset('dist/_partials/ajax/ajax.js') }}"></script>
        <script src="{{ asset('dist/_partials/control-sidebar/control-sidebar.js') }}"></script>

        <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js"></script>
        <script>
            $(function(){
                var OneSignal = window.OneSignal || [];
                OneSignal.push(function() {
                    OneSignal.init({
                        appId: "f3ea2b5f-1802-46ed-9edb-d68a67ccd336",
                    });
                    OneSignal.sendTags({
                        user_id: '{{ Auth::user()->id }}', 
                        is_admin: '{{ Auth::user()->is_admin }}',
                        user_name: '{{ Auth::user()->name }}', 
                    });
                    OneSignal.push(function() {
                        OneSignal.showHttpPrompt();
                    });
                });
            });
        </script>
        @yield('footer-extras')

        @stack('footer-scripts')
    </body>
</html>

