<script src="{{ asset('/dist/_partials/select2/select2.js') }}"></script>
<script src="{{ asset('/dist/'.str_replace('.', '/', $resourceAlias).'/form.js') }}"></script>