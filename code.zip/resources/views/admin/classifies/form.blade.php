@if ($record && $record->deleted_at)
    <div id="deny" data-list-url="{{ route($resourceRoutesAlias.'.index', ['record-status' => get_default_record_status()]) }}"></div>
@else
    <div id="default-record-status" class="col-md-9" data-default-record-status="{{ get_default_record_status() }}">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="group" class="form-control-label">Thuộc nhóm</label>
                    <select id="group" name="group" class="form-control{{ $errors->has('group') ? ' is-invalid' : '' }}">
                        <option value="" {{ old('group', isset($record->group) ? $record->group : $classifies['group']) == '' ? 'selected' : '' }}>Hãy chọn nhóm</option>
                        @foreach ($classifies['groups'] as $group)
                            <option value="{{ $group->id }}" {{ old('group', isset($record->group) ? $record->group : $classifies['group']) == $group->id ? 'selected' : '' }}>{{ $group->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('group'))
                        <div class="invalid-feedback">Nhóm {{ $errors->first('group') }}</div>
                    @endif
                </div>
                <!-- /.form-group -->
            </div>
            <!-- col-md-6 -->
        </div>
        <!-- row -->
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="sub-id" class="form-control-label">ID thứ cấp</i></label>
                    <input id="sub-id" type="number" min="1" class="form-control{{ $errors->has('sub_id') ? ' is-invalid' : '' }}" name="sub_id" value="{{ old('sub_id', $record->sub_id) }}" required>
                    @if ($errors->has('sub_id'))
                        <div class="invalid-feedback">ID thứ cấp {{ $errors->first('sub_id') }}</div>
                    @endif
                </div>
                <!-- /.form-group -->
            </div>
            <!-- col-md-6 -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="display-no" class="form-control-label">Thứ tự hiển thị</i></label>
                    <input id="display-no" type="number" min="1" class="form-control{{ $errors->has('display_no') ? ' is-invalid' : '' }}" name="display_no" value="{{ old('display_no', $record->display_no) }}" required>
                    @if ($errors->has('display_no'))
                        <div class="invalid-feedback">Thứ tự hiển thị {{ $errors->first('display_no') }}</div>
                    @endif
                </div>
                <!-- /.form-group -->
            </div>
            <!-- col-md-6 -->
        </div>
        <!-- row -->
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="name" class="form-control-label">Tên hiển thị</label>
                    <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name', $record->name) }}" required>
                    @if ($errors->has('name'))
                        <div class="invalid-feedback">Tên hiển thị {{ $errors->first('name') }}</div>
                    @endif
                </div>
                <!-- /.form-group -->
            </div>
            <!-- col-md-6 -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="value" class="form-control-label">Giá trị</i></label>
                    <input id="value" type="text" class="form-control{{ $errors->has('value') ? ' is-invalid' : '' }}" name="value" value="{{ old('value', $record->value) }}">
                    @if ($errors->has('value'))
                        <div class="invalid-feedback">Giá trị {{ $errors->first('value') }}</div>
                    @endif
                </div>
                <!-- /.form-group -->
            </div>
            <!-- col-md-6 -->
        </div>
        <!-- row -->
    </div>
    <!-- /.col-md-9 -->
    <input type="hidden" name="classifies" />
@endif