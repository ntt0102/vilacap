<?php
  $color = get_color();
?>

{{-- Extends Layout --}}
@extends('layouts.backend', ['theme' => $color->theme, 'skin' => $color->skin])

<?php
    $_pageTitle = 'Nhật ký';
    $_pageTitleLower = mb_strtolower($_pageTitle);
    $resourceAlias = 'admin.logs';

    $tableCounter = 0;
    if (count($records) > 0) {
        $tableCounter = ($records->currentPage() - 1) * $records->perPage();
        $tableCounter = $tableCounter > 0 ? $tableCounter : 0;
    }
?>

{{-- Breadcrumbs --}}
@section('breadcrumbs')
    {!! Breadcrumbs::render('logs') !!}
@endsection

{{-- Page Title --}}
@section('page-title', $_pageTitle)

{{-- Header Extras to be Included --}}
@section('head-extras')
    <link rel="stylesheet" href="{{ asset('dist/_partials/select2/select2.css') }}">
    <link rel="stylesheet" href="{{ asset('dist/admin/logs/logs.css') }}">
@endsection

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card card-skin card-{{ $color->skin }} card-outline">
                <div class="card-header">
                    <h3 class="card-title">&nbsp;<span class="d-none d-sm-inline-block">Danh sách</span></h3>
                    <!-- Search -->
                    <div class="card-tools">
                        <form id="formSearch" method="GET" action="{{ route('admin::logs') }}">
                            <div class="input-group input-group-sm" style="width: 250px;">
                                <input type="text" name="search" class="form-control float-right" value="{{ $search }}" placeholder="Tìm kiếm" autofocus>
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-skin btn-{{ $color->skin }}"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- END Search -->
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    @includeIf($resourceAlias.'.filter')
                    @if (count($records) > 0)
                        @includeIf($resourceAlias.'.table')
                    @else
                        <p class="lead pl-3 pt-2">Không tìm thấy {{ $_pageTitleLower }} nào.</p>
                    @endif
                </div>
                <!-- /.card-body -->
                @if (count($records) > 0)
                    @includeIf('common.paginate', ['records' => $records])
                @endif
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col-md-9 -->
    </div>
    <!-- /.row -->
@endsection

{{-- Footer Extras to be Included --}}
@section('footer-extras')
    <script src="{{ asset('/dist/_partials/select2/select2.js') }}"></script>
    <script src="{{ asset('/dist/admin/logs/logs.js') }}"></script>
@endsection
