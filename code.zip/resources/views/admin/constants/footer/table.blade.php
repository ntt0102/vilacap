<script src="{{ asset('/dist/'.str_replace('.', '/', $resourceAlias).'/table.js') }}"></script>
