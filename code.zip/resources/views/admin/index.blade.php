<?php
  $color = get_color();
?>

{{-- Extends Layout --}}
@extends('layouts.backend', ['theme' => $color->theme, 'skin' => $color->skin])

{{-- Breadcrumbs --}}
@section('breadcrumbs')
    {!! Breadcrumbs::render('dashboard') !!}
@endsection

{{-- Page Title --}}
@section('page-title', 'Tổng quan')

{{-- Header Extras to be Included --}}
@section('head-extras')

@endsection

@section('content')
  <div class="row">
    <div class="col-lg-3 col-6">
      <!-- small card -->
      <div class="small-box bg-success">
        <div class="inner">
          <h3>{{ $reports->getTotalUsers() }}</h3>
          <p>Thành viên</p>
        </div>
        <div class="icon">
          <i class="fas fa-users"></i>
        </div>
        <a href="{{ route('admin::users.index') }}" class="small-box-footer">
          Danh sách thành viên  <i class="fa fa-arrow-circle-right"></i>
        </a>
      </div>
    </div>
  </div>
@endsection

{{-- Footer Extras to be Included --}}
@section('footer-extras')

@endsection
