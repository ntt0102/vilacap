<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label for="record-status" class="form-control-label">Trạng thái giao dịch</label>
            <select id="record-status" name="record-status" class="form-control load">
                <option value="0" {{ $classifies['record_status'] == '' ? 'selected' : '' }}>Tất cả</option>
                @foreach ($classifies['record_statuses'] as $record_status)
                    <option value="{{ $record_status->sub_id }}" {{ $classifies['record_status'] == $record_status->sub_id ? 'selected' : '' }}>{{ $record_status->name }}</option>
                @endforeach
            </select>
        </div>
        <!-- form-group -->
    </div>
    <!-- col-md-3 -->
    <div class="col-md-3">
        <div class="form-group">
            <label for="order-by" class="form-control-label">Sắp xếp theo</label>
            <select id="order-by" name="order-by" class="form-control load">
                <option value="" {{ $classifies['order_by'] == '' ? 'selected' : '' }}>Chọn trường sắp xếp</option>
                @foreach ($classifies['bys'] as $by)
                    @foreach ($classifies['orders'] as $order)
                        <option value="{{ $by->sub_id }}-{{ $order->sub_id }}" {{ $classifies['order_by'] == $by->sub_id.'-'.$order->sub_id ? 'selected' : '' }}>{{ $by->name }} - {{ $order->name }}
                    @endforeach
                @endforeach
            </select>
        </div>
        <!-- form-group -->
    </div>
    <!-- col-md-3 -->
</div>
<!-- row -->