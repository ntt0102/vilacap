<div class=" table-responsive">     
    <table class="table table-hover">
        <th>#</th>
        <th>ID</th>
        <th>Trạng thái</th>
        <th style="min-width: 180px;">Tên tài khoản</th>
        <th style="min-width: 110px;">Loại</th>
        <th>Số tiền (đồng)</th>
        <th style="min-width: 100px;">Thời hạn (năm)</th>
        <th>Ngày mua</th>
        <th>Ngày đáo hạn</th>
        @if (! in_array($classifies['record_status'], [1, 3]))
            <th>Ngày bán</th>
        @endif
        @if (! in_array($classifies['record_status'], [1, 2]))
            <th style="min-width: 100px;">Đã xóa lúc</th>
        @endif
        <th>Cập nhật lúc</th>
        <th style="min-width: 100px;">Cập nhật bởi</th>
        <th style="width: 100px;">Hành động</th>

        @foreach ($records as $record)
            <?php
            $tableCounter++;
            if (! $record->deleted_at) {
                if (! $record->sold_at){
                    $sellToggleLink = route($resourceRoutesAlias.'.sell', $record->id);
                    $formSellToggleId = 'formSellToggle_'.$record->id;
                    //
                    $downloadPDFLink = route($resourceRoutesAlias.'.downloadPDF', $record->id);
                    //
                    $editLink = route($resourceRoutesAlias.'.edit', $record->id);
                }
                else {
                    $destroyToggleLink = route($resourceRoutesAlias.'.destroy', $record->id);
                    $formDestroyToggleId = 'formDestroyToggle_'.$record->id;
                }
            }
            else {
                $destroyToggleLink = route($resourceRoutesAlias.'.destroy', $record->id);
                $formDestroyToggleId = 'formDestroyToggle_'.$record->id;
            }
            
            ?>
            @if (! $record->deleted_at)
                <tr class="load" title="Nhấn đúp để sửa" >
            @else 
                <tr>
            @endif
                <td>{{ $tableCounter }}</td>
                <td>
                    @if (! $record->deleted_at && ! $record->sold_at)
                        <a href="{{ $editLink }}">{{ $record->id }}</a>
                    @else {{ $record->id }} @endif
                </td>
                <td>
                    @if ($record->deleted_at) 
                        <span class="badge bg-dark">{{ $classifies['record_statuses'][2]->name }}</span>
                    @else
                        @if (! $record->sold_at)
                            <span class="badge bg-success">{{ $classifies['record_statuses'][0]->name }}</span>
                        @else
                            <span class="badge bg-secondary">{{ $classifies['record_statuses'][1]->name }}</span>
                        @endif
                    @endif
                </td>
                <td>{{ $record->user_name }}</td>
                <td>{{ $record->type_name }}</td>
                <td>{{ currency_format($record->cost) }}</td>
                <td>{{ $record->periods_name }}</td>
                <td>{{ date("d/m/Y", strtotime($record->buyed_at)) }}</td>
                <td>{{ date("d/m/Y", strtotime($record->due_date)) }}</td>
                @if (! in_array($classifies['record_status'], [1, 3]))
                    <td>{{ $record->sold_at ? date("d/m/Y", strtotime($record->sold_at)) : '' }}</td>
                @endif
                @if (! in_array($classifies['record_status'], [1, 2]))
                    <td>{{ $record->deleted_at ? date("H:i d/m/Y", strtotime($record->deleted_at)) : ''}}</td>
                @endif
                <td>{{ date("H:i d/m/Y", strtotime($record->updated_at)) }}</td>
                <td>{{ $record->modified_name }}</td>

                <!-- we will also add show, edit, and delete buttons -->
                <td>
                    <div class="btn-group">
                        <button type="button" class="btn btn-skin btn-{{ $record->deleted_at ? 'dark' : $color->skin }} dropdown-toggle" data-toggle="dropdown"></button>
                        <div class="dropdown-menu">
                            @if (! $record->deleted_at)
                                @if (! $record->sold_at)
                                    <a href="#" class="dropdown-item btnSellToggle load-none" data-form-id="{{ $formSellToggleId }}" data-status="2"><i class="fas fa-stop-circle text-success"></i> Bán</a>
                                    <a href="{{ $downloadPDFLink }}" class="dropdown-item load-none"><i class="fas fa-download text-secondary"></i> Tải file PDF</a>
                                    <a href="{{ $editLink }}" class="dropdown-item edit"><i class="fas fa-edit text-info"></i> Sửa</a>
                                @else
                                    <a href="#" class="dropdown-item btnDeleteToggle load-none" data-form-id="{{ $formDestroyToggleId }}" data-status="2"><i class="fas fa-trash-alt text-danger"></i> Xóa</a>
                                @endif
                            @else
                                <a href="#" class="dropdown-item btnDeleteToggle load-none" data-form-id="{{ $formDestroyToggleId }}" data-status="1"><i class="fas fa-undo text-dark"></i> Khôi phục</a>
                            @endif
                        </div>
                    </div>
                    @if (! $record->deleted_at && ! $record->sold_at)
                        <!-- Close Contract Form -->
                        <form id="{{ $formSellToggleId }}" action="{{ $sellToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                            {{ csrf_field() }}
                            <input type="hidden" name="classifies" />
                        </form>
                    @endif
                    @if ($record->sold_at)
                        <!-- Disable/Enable Record Form -->
                        <form id="{{ $formDestroyToggleId }}" action="{{ $destroyToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                            {{ csrf_field() }}
                            {{ method_field('DELETE') }}
                            <input type="hidden" name="classifies" />
                        </form>
                    @endif
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
