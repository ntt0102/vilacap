<link rel="stylesheet" href="{{ asset('dist/_partials/datepicker/datepicker.css') }}">
<link rel="stylesheet" href="{{ asset('dist/_partials/select2/select2.css') }}">