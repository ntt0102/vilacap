<div class=" table-responsive">     
    <table class="table table-hover">
        <th>#</th>
        <th>Mã giao dịch</th>
        <th>Trạng thái</th>
        <th style="min-width: 110px;">Loại</th>
        <th>Số tiền (đồng)</th>
        <th style="min-width: 110px;">Phương thức</th>
        <th style="min-width: 110px;">Thời gian</th>
        @if ($classifies['record_status'] != 2)
            <th style="width: 100px;">Hành động</th>
        @endif

        @foreach ($records as $record)
            <?php
                $tableCounter++;
                //
                if (! $record->deleted_at && ! $record->confirmed_at) {
                    $editLink = route($resourceRoutesAlias.'.edit', $record->id);
                    $destroyToggleLink = route($resourceRoutesAlias.'.destroy', $record->id);
                    $formDestroyToggleId = 'formDestroyToggle_'.$record->id;
                }
            ?>
            @if (! $record->deleted_at && ! $record->confirmed_at)
                <tr title="Nhấn đúp để sửa" >
            @else 
                <tr>
            @endif
                <td>{{ $tableCounter }}</td>
                <td>
                    @if (! $record->deleted_at && ! $record->confirmed_at)
                        <a href="{{ $editLink }}">{{ 'GDT'.str_pad($record->id, 5, '0', STR_PAD_LEFT) }}</a>
                    @else {{ 'GDT'.str_pad($record->id, 5, '0', STR_PAD_LEFT) }} @endif
                </td>
                <td>
                    @if ($record->confirmed_at) 
                        <span class="badge bg-secondary">{{ $classifies['record_statuses'][1]->name }}</span>
                    @else
                        <span class="badge bg-success">{{ $classifies['record_statuses'][0]->name }}</span>
                    @endif
                </td>
                <td>{{ $record->type_name }}</td>
                <td>{{ currency_format($record->cost) }}</td>
                <td>{{ $record->method_name }}</td>
                <td>{{ date("H:i d/m/Y", strtotime($record->created_at)) }}</td>

                <!-- we will also add show, edit, and delete buttons -->
                @if ($classifies['record_status'] != 2)
                <td>
                    @if (!(!$record->deleted_at && $record->confirmed_at))
                    <div class="btn-group">
                        <button type="button" class="btn btn-skin btn-{{ $record->deleted_at ? 'dark' : $color->skin }} dropdown-toggle" data-toggle="dropdown"></button>
                        <div class="dropdown-menu">
                            @if (! $record->deleted_at && ! $record->confirmed_at)
                                <a href="{{ $editLink }}" class="dropdown-item edit"><i class="fas fa-edit text-info"></i> Sửa</a>
                                <a href="#" class="dropdown-item btnDeleteToggle load-none" data-form-id="{{ $formDestroyToggleId }}" data-status="2"><i class="fas fa-trash-alt text-danger"></i> Xóa</a>
                            @endif
                        </div>
                    </div>
                    @endif

                    @if (! $record->deleted_at && ! $record->confirmed_at)
                        <!-- Disable Record Form -->
                        <form id="{{ $formDestroyToggleId }}" action="{{ $destroyToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                            {{ csrf_field() }}
                            {{ method_field('DELETE') }}
                            <input type="hidden" name="classifies" />
                        </form>
                    @endif
                </td>
                @endif
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
