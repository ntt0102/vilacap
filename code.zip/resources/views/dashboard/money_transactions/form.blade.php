@if ($record && $record->deleted_at)
    <div id="deny" data-error="2" data-list-url="{{ route('dashboard::money_transactions.index', ['record-status' => get_default_record_status()]) }}"></div>
@elseif ($record && $record->confirmed_at)
    <div id="deny" data-error="1" data-list-url="{{ route('dashboard::money_transactions.index', ['record-status' => get_default_record_status()]) }}"></div>
@else
    <div id="default-status" class="col-md-9" data-default-record-status="{{ get_default_record_status() }}">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="type" class="form-control-label">Loại</label>
                    <select id="type" name="type" class="form-control{{ $errors->has('type') ? ' is-invalid' : '' }}">
                        <option value="" {{ old('type', $record->type) == '' ? 'selected' : '' }}>Hãy chọn loại</option>
                        @foreach ($classifies['types'] as $type)
                            <option value="{{ $type->sub_id }}" {{ old('type', $record->type) == $type->sub_id ? 'selected' : '' }}>{{ $type->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('type'))
                        <div class="invalid-feedback">Loại {{ $errors->first('type') }}</div>
                    @endif
                </div>
                <!-- /.form-group -->
            </div>
            <!-- col-md-6 -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="_cost" class="form-control-label">Số tiền (đồng)</i></label>
                    <input id="_cost" type="text" class="form-control{{ $errors->has('cost') ? ' is-invalid' : '' }}" value="{{ old('cost', $record->cost) ? currency_format(old('cost', $record->cost)) : '' }}" required>
                    <input id="cost" type="hidden" name="cost" value="{{ old('cost', $record->cost) }}">
                    @if ($errors->has('cost'))
                        <div class="invalid-feedback">Số tiền {{ $errors->first('cost') }}</div>
                    @endif
                </div>
                <!-- /.form-group -->
            </div>
            <!-- col-md-6 -->
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="method" class="form-control-label">Phương thức</label>
                    <select id="method" name="method" class="form-control{{ $errors->has('method') ? ' is-invalid' : '' }}">
                        <option value="" {{ old('method', $record->method) == '' ? 'selected' : '' }}>Hãy chọn phương thức</option>
                        @foreach ($classifies['methods'] as $period)
                            <option value="{{ $period->sub_id }}" {{ old('method', $record->method) == $period->sub_id ? 'selected' : '' }}>{{ $period->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('method'))
                        <div class="invalid-feedback">Phương thức {{ $errors->first('method') }}</div>
                    @endif
                </div>
                <!-- /.form-group -->
            </div>
            <!-- col-md-6 -->
        </div>
        <!-- row -->
    </div>
    <!-- /.col-md-9 -->
    <input type="hidden" name="classifies" />
@endif