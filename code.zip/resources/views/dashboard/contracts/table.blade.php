<div class=" table-responsive">     
    <table class="table table-hover">
        <th>#</th>
        <th>ID</th>
        <th>Trạng thái</th>
        <th style="min-width: 110px;">Loại</th>
        <th>Số tiền (đồng)</th>
        <th style="min-width: 100px;">Thời hạn (năm)</th>
        <th>Ngày mua</th>
        <th>Ngày đáo hạn</th>
        @if ($classifies['record_status'] != 1)
            <th>Ngày bán</th>
        @endif
        @if ($classifies['record_status'] != 2)
            <th style="width: 100px;">Hành động</th>
        @endif

        @foreach ($records as $record)
            <?php
                $tableCounter++;
                if (!$record->deleted_at && ! $record->sold_at) {
                    $downloadPDFLink = route($resourceRoutesAlias.'.downloadPDF', $record->id);
                    $sellToggleLink = route($resourceRoutesAlias.'.sell', $record->id);
                    $formSellToggleId = 'formSellToggle_'.$record->id;
                }
            ?>
            <tr>
                <td>{{ $tableCounter }}</td>
                <td>{{ $record->id }}</td>
                <td>
                    @if (! $record->sold_at)
                        <span class="badge bg-success">{{ $classifies['record_statuses'][0]->name }}</span>
                    @else
                        <span class="badge bg-secondary">{{ $classifies['record_statuses'][1]->name }}</span>
                    @endif
                </td>
                <td>{{ $record->type_name }}</td>
                <td>{{ currency_format($record->cost) }}</td>
                <td>{{ $record->periods_name }}</td>
                <td>{{ date("d/m/Y", strtotime($record->buyed_at)) }}</td>
                <td>{{ date("d/m/Y", strtotime($record->due_date)) }}</td>
                @if (! in_array($classifies['record_status'], [1, 3]))
                    <td>{{ $record->sold_at ? date("d/m/Y", strtotime($record->sold_at)) : '' }}</td>
                @endif

                <!-- we will also add show, edit, and delete buttons -->
                @if ($classifies['record_status'] != 2)
                <td>
                    @if (! $record->deleted_at && ! $record->sold_at)
                        <div class="btn-group">
                            <button type="button" class="btn btn-skin btn-{{ $record->deleted_at ? 'dark' : $color->skin }} dropdown-toggle" data-toggle="dropdown"></button>
                            <div class="dropdown-menu">
                                <a href="{{ $downloadPDFLink }}" class="dropdown-item load-none"><i class="fas fa-download text-secondary"></i> Tải file PDF</a>
                                <a href="#" class="dropdown-item btnSellToggle load-none" data-form-id="{{ $formSellToggleId }}"><i class="fas fa-stop-circle text-success"></i> Bán hợp đồng</a>
                            </div>
                        </div>
                    @endif

                    @if (! $record->deleted_at && ! $record->sold_at)
                        <!-- Close Contract Form -->
                        <form id="{{ $formSellToggleId }}" action="{{ $sellToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                            {{ csrf_field() }}
                            <input type="hidden" name="classifies" />
                        </form>
                    @endif
                </td>
                @endif
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
