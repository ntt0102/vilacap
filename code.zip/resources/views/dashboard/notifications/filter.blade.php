<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label for="status" class="form-control-label">Trạng thái thông báo</label>
            <select id="status" class="form-control load">
                <option value="" {{ $classifies['status'] == '' ? 'selected' : '' }}>Tất cả</option>
                @foreach ($classifies['statuses'] as $status)
                    <option value="{{ $status->sub_id }}" {{ $classifies['status'] == $status->sub_id ? 'selected' : '' }}>{{ $status->name }}</option>
                @endforeach
            </select>
        </div>
        <!-- form-group -->
    </div>
    <!-- col-md-3 -->
    <div class="col-md-3">
        <div class="form-group">
            <label for="type" class="form-control-label">Loại thông báo</label>
            <select id="type" class="form-control load">
                <option value="0" {{ $classifies['type'] == '' ? 'selected' : '' }}>Tất cả</option>
                @foreach ($classifies['types'] as $type)
                    <option value="{{ $type->sub_id }}" {{ $classifies['type'] == $type->sub_id ? 'selected' : '' }}>{{ $type->name }}</option>
                @endforeach
            </select>
        </div>
        <!-- form-group -->
    </div>
    <!-- col-md-3 -->
    <div class="col-md-3">
        <div class="form-group">
            <label for="interval" class="form-control-label">Xem cách đây</label>
            <select id="interval" class="form-control load">
                <option value="" {{ $classifies['interval'] == '' ? 'selected' : '' }}>Tất cả</option>
                @foreach ($classifies['time_units'] as $time_unit)
                    @for ($i = 1; $i <= $classifies['time_periods']; $i++)
                        <option value="{{ $i.'-'.$time_unit->sub_id }}" {{ $classifies['interval'] == $i.'-'.$time_unit->sub_id ? 'selected' : '' }}>{{ $i.' '.$time_unit->name }}</option>
                    @endfor
                @endforeach
            </select>
        </div>
        <!-- form-group -->
    </div>
    <!-- col-md-3 -->
</div>
<!-- row -->