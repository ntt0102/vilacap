@extends('layouts.pdfs')

{{-- Page Title --}}
@section('page-title', 'HopDong-'.($user->is_admin ? 'A' : 'M').'-'.str_pad($user->id, 5, '0', STR_PAD_LEFT).'_'.date("H-i_d-m-Y", time()))

{{-- Header Extras to be Included --}}
@section('head-extras')
	<style type="text/css">

            .contract{
              margin-bottom: 10px;
              padding-right: 250px;
            }

            .contract .title {
              float: right;
              text-align: right;
            }

            .contract .title h1 {
              color: #28a745;
              font-size: 2.0em;
              line-height: 1em;
              font-weight: normal;
              margin: 0  0 10px 0;
            }

            .contract .title .extra {
              font-size: 0.9em;
              color: #777777;
            }

            .content {
              margin-bottom: 30px;
              font-size: 1.1em;
            }

            .content .item{
              font-weight: bold;
              padding: 4px 0;
            }

            .content .item span{
              font-weight: normal;
            }

            .signature{
              padding-right: 245px;
            }

            .signature-a{
              float: right;
              text-align: center;

            }

            .signature-b{
              float: left;
              text-align: center;
              padding-right: 200px;
            }

            .break { 
                page-break-inside: avoid; 
                page-break-after: always; 
            }
        </style>
@endsection

@section('content')
	<div class="contract clearfix">
		<div class="title">
			<h1>BẢN HỢP ĐỒNG</h1>
      <div class="extra">Ngày lập biên bản: {{ date("d/m/Y", time()) }}</div>
      <div class="extra">Mã hợp đồng: {{ ($user->is_admin ? 'A' : 'M').'-'.str_pad($user->id, 5, '0', STR_PAD_LEFT) }}</div>
		</div>
	</div>
	<div class="content clearfix">
    <h3>BÊN BITMO (BÊN A):</h3>
    <?php
      $admin = App\User::where('id', '=', 1)->get()->first();
    ?>
    <div class="item">Người đại diện: <span>{{ $admin->name }}</span></div>
    <div class="item">Địa chỉ: <span>{{ $admin->residence }}</span></div>
    <div class="item">Số điện thoại: <span>{{ phone_format($admin->phone) }}</span></div>
    <div class="item">Địa chỉ email: <span>{{ $admin->email }}</span></div>

    <h3>BÊN KHÁCH HÀNG (BÊN B):</h3>
    <div class="item">Tên khách hàng: <span>{{ $user->name }}</span></div>
    <div class="item">Số CMND: <span>{{ $user->username }}</span></div>
    <div class="item">Ngày sinh: <span>{{ date("d/m/Y", strtotime($user->birthday)) }}</span></div>
    <div class="item">Giới tính: <span>{{ $user->gender_name }}</span></div>
    <div class="item">Địa chỉ: <span>{{ $user->residence }}</span></div>
    <div class="item">Số điện thoại: <span>{{ phone_format($user->phone) }}</span></div>
    <div class="item">Địa chỉ email: <span>{{ $user->email }}</span></div>
    <br><br>  
    <div>Thỏa thuận ký kết hợp đồng và cam kết làm đúng những điều khoản được nêu rõ ở trang bên.</div>
  </div>
	<div class="signature">
    <div class="signature-b">
      <div class="signature-header">Bên B</div>
      <div class="comment">(Ký và ghi rõ họ tên)</div>
    </div>
    <div class="signature-a">
      <div class="signature-header">Bên A</div>
      <div class="comment">(Ký và ghi rõ họ tên)</div>
    </div>
  </div>
  <!-- <div class="break"></div> -->
@endsection