@extends('layouts.errors')

@section('title', 'Be right back')

@section('message', 'Be right back.')
