@extends('layouts.errors')

@section('title', 'Forbidden')

@section('message', '403, Forbidden.')
