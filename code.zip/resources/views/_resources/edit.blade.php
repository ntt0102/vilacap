<?php
  $color = get_color();
?>

{{-- Extends Layout --}}
@extends('layouts.backend', ['theme' => $color->theme, 'skin' => $color->skin])

<?php
    $_pageTitle = ucfirst($resourceTitle);
    $_formFiles = isset($addVarsForView['formFiles']) ? $addVarsForView['formFiles'] : false;
    $_listLink = route($resourceRoutesAlias.'.index');
    $_createLink = route($resourceRoutesAlias.'.create');
    $_updateLink = route($resourceRoutesAlias.'.update', $record->id);
?>

{{-- Breadcrumbs --}}
@section('breadcrumbs')
    {!! Breadcrumbs::render($resourceRoutesAlias.'.edit', $record->id) !!}
@endsection

{{-- Page Title --}}
@section('page-title', $_pageTitle)

{{-- Header Extras to be Included --}}
@section('head-extras')
    @includeIf($resourceAlias.'.header.form')
@endsection

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card card-skin card-{{ $color->skin }} card-outline">
                <form class="form" role="form" method="POST" action="{{ $_updateLink }}" {{ $_formFiles === true ? 'enctype="multipart/form-data"' : ''}}>
                    {{ csrf_field() }}
                    {{ method_field('PUT') }}
                    {{ redirect_back_field() }}

                    <div class="card-header">
                        <h3 class="card-title">&nbsp;<span class="d-none d-sm-inline-block">{{ $editSubtitle }}</span></h3>
                        <div class="card-tools">
                            <span id="btnList" data-link="{{ $_listLink }}" class="btn btn-sm btn-skin btn-{{ $color->skin }} mr-1">
                                {!! $listButtonName !!}
                            </span>
                            <span id="btnCreate" data-link="{{ $_createLink }}" class="btn btn-sm btn-skin btn-{{ $color->skin }} mr-1">
                                {!! $createButtonName !!}
                            </span>
                        </div>
                        <!-- /.card-tools -->
                    </div>
                    <!-- /.card-header -->   
                    <div class="card-body">   
                        <div class="row">
                            @includeIf($resourceAlias.'.form')
                        </div>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-skin btn-{{ $color->skin }}">
                                    <i class="fas fa-save"></i> <span>Lưu</span>
                                </button>
                                <span id="btnCancel" data-link="{{ $_listLink }}" class="btn btn-default ml-3 load">
                                    <i class="fas fa-ban"></i> <span>Hủy</span>
                                </span>
                            </div>
                            <!-- /.col-md-9 -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.card-footer -->
                </form>
                <!-- /form -->
            </div>
            <!-- /.card -->
        </div>
    </div>
@endsection

{{-- Footer Extras to be Included --}}
@section('footer-extras')
    @includeIf($resourceAlias.'.footer.form')
@endsection
