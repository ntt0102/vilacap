<?php
  $skin = get_color()->skin;
?>
@extends('layouts.frontend', ['skin' => $skin])

{{-- Page Title --}}
@section('page-title', 'Đăng ký')

@section('head-extras')
    <link rel="stylesheet" href="{{ asset('dist/_partials/datepicker/datepicker.css') }}">
    <link rel="stylesheet" href="{{ asset('dist/_partials/select2/select2.css') }}">
    <link rel="stylesheet" href="{{ asset('dist/auth/register/register.css') }}">
@endsection

{{-- Main content --}}
@section('content')
    @if ($errors->any())
    <div class="alert alert-error">
        Rất tiếc! Đã xảy ra lỗi. Xin vui lòng kiểm tra lại thông tin được đánh dấu bên dưới.
    </div>
    @endif
    <div class="register-box">
        <div class="card">
            <div class="card-body">
                <p class="box-msg">Đăng ký để truy cập hệ thống</p>
                <form method="POST" action="{{ route('register') }}">
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="name" class="form-control-label">Họ tên <i class="far fa-question-circle" title="Họ tên phải khớp với CMND"></i></label>
                                <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name') }}" pattern="[A-Za-z].{5,}" required autofocus>
                                @if ($errors->has('name'))
                                    <div class="invalid-feedback">Họ tên {{ $errors->first('name') }}</div>
                                @endif
                            </div>
                            <!-- /.form-group -->
                        </div>
                        <!-- col-md-6 -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="username" class="form-control-label">CMND</label>
                                <input id="username" type="text" class="form-control{{ $errors->has('username') ? ' is-invalid' : '' }}" name="username" value="{{ old('username') }}" pattern="[0-9]{9}" required>
                                @if ($errors->has('username'))
                                    <div class="invalid-feedback">CMND {{ $errors->first('username') }}</div>
                                @endif
                            </div>
                            <!-- /.form-group -->
                        </div>
                        <!-- col-md-6 -->
                    </div>
                    <!-- row -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="password" class="form-control-label">Mật khẩu <i class="far fa-question-circle" title="Mật khẩu phải chứa ít nhất một số, một chữ hoa, một chữ thường và ít nhất 6 ký tự trở lên"></i></label>
                                <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" value="{{ old('password') }}" required>
                                @if ($errors->has('password'))
                                    <div class="invalid-feedback">Mật khẩu {{ $errors->first('password') }}</div>
                                @endif
                            </div>
                            <!-- /.form-group -->
                        </div>
                        <!-- col-md-6 -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="password-confirm" class="form-control-label">Xác nhận mật khẩu</label>
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" value="{{ old('password_confirmation') }}"required>
                            </div>
                            <!-- /.form-group -->
                        </div>
                        <!-- col-md-6 -->
                    </div>
                    <!-- row -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="gender" class="form-control-label">Giới tính</label>
                                <select id="gender" name="gender" class="form-control{{ $errors->has('gender') ? ' is-invalid' : '' }}">
                                    <option value="" {{ old('gender') == '' ? 'selected' : '' }}>Chọn giới tính</option>
                                    <option value="1" {{ old('gender') == '1' ? 'selected' : '' }}>Nam</option>
                                    <option value="0" {{ old('gender') == '0' ? 'selected' : '' }}>Nữ</option>
                                </select>
                                @if ($errors->has('gender'))
                                    <div class="invalid-feedback">Giới tính {{ $errors->first('gender') }}</div>
                                @endif
                            </div>
                            <!-- /.form-group -->
                        </div>
                        <!-- col-md-6 -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="birthday" class="form-control-label">Ngày sinh <i class="far fa-question-circle" title="Ngày sinh phải có dạng DD/MM/YYYY"></i></label>
                                <div class="input-group date">
                                  <input id="birthday" type="text" class="form-control{{ $errors->has('birthday') ? ' is-invalid' : '' }}" name="birthday" value="{{ old('birthday') }}" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])/(?:0[1-9]|1[0-2]))|(30/(?:01|0[3-9]|1[0-2]))|(31/(?:0[13578]|1[02])))/((?:19|20)[0-9]{2})" required>
                                  <span class="input-group-text input-group-addon"><i class="fa fa-calendar"></i></span>
                                </div>
                                @if ($errors->has('birthday'))
                                    <div class="invalid-feedback">Ngày sinh {{ $errors->first('birthday') }}</div>
                                @endif
                            </div>
                            <!-- /.form-group -->
                        </div>
                        <!-- col-md-6 -->
                    </div>
                    <!-- row -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="residence" class="form-control-label">Nơi cư trú <i class="far fa-question-circle" title="Ví dụ: Thôn 4, Quế Thuận, Quế Sơn, Quảng Nam"></i></label>
                                <input id="residence" type="text" class="form-control{{ $errors->has('residence') ? ' is-invalid' : '' }}" name="residence" value="{{ old('residence') }}" pattern="(.{4,})(, )(.{5,})(, )(.{5,})(, )(.{5,})" required>
                                @if ($errors->has('residence'))
                                    <div class="invalid-feedback">Nơi cư trú {{ $errors->first('residence') }}</div>
                                @endif
                            </div>  
                            <!-- /.form-group -->
                        </div>
                        <!-- col-md-6 -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="phone" class="form-control-label">Số điện thoại</label>
                                <input id="phone" type="text" class="form-control{{ $errors->has('phone') ? ' is-invalid' : '' }}" name="phone" value="{{ old('phone') }}" pattern="0(?:8|9|12|16)[0-9]{8}" required>
                                @if ($errors->has('phone'))
                                    <div class="invalid-feedback">Số điện thoại {{ $errors->first('phone') }}</div>
                                @endif
                            </div>
                            <!-- /.form-group -->
                        </div>
                        <!-- col-md-6 -->
                    </div>
                    <!-- row -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email" class="form-control-label">Email</label>
                                <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>
                                @if ($errors->has('email'))
                                    <div class="invalid-feedback">Email {{ $errors->first('email') }}</div>
                                @endif
                            </div>
                        </div>
                        <!-- col-md-6 -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="captcha" class="form-control-label">Mã captcha</label>
                                <input id="captcha" type="text" class="form-control{{ $errors->has('captcha') ? ' is-invalid' : '' }}" name="captcha" value="{{ old('captcha') }}" required>
    
                                <div class="captcha form-group mt-2">
                                       <button type="button" class="mr-2 btn btn-{{ $skin }}"><i class="fas fa-sync-alt" id="refresh"></i></button>
                                       <span>{!! captcha_img() !!}</span>
                                </div>
                                
                                @if ($errors->has('captcha'))
                                    <div class="invalid-feedback">{{ $errors->first('captcha') }}</div>
                                @endif
                            </div>
                            <!-- /.form-group -->
                        </div>
                        <!-- col-md-6 -->
                    </div>
                    <!-- row -->
                    <div class="row">
                        <div class="form-group col-md-12">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="terms" name="terms" {{ old('terms') ? 'checked' : '' }}>
                                <label class="custom-control-label" for="terms">Tôi đồng ý với <a href="#">các điều khoản và điều kiện</a></label>
                            </div>
                            <!-- /.custom-control -->
                        </div>
                        <!-- /.form-group -->
                        <div class="form-group col-md-12">
                            <button type="submit" class="btn btn-{{ $skin }}" {{ old('terms') ? '' : 'disabled' }}>Đăng ký</button>
                        </div>
                        <!-- /.form-group -->
                    </div>
                    <!-- row -->
                    <p class="box-msg"><em>Nếu bạn đã có tài khoản hãy đăng nhập tại <a href="{{ route('login') }}">đây</a></em></p>
                </form>
                <!-- /form -->
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <!-- /.register-box -->
@endsection

{{-- Footer-extras --}}
@section('footer-extras')
    <script src="{{ asset('/dist/_partials/datepicker/datepicker.js') }}"></script>
    <script src="{{ asset('/dist/_partials/select2/select2.js') }}"></script>
    <script src="{{ asset('/dist/auth/register/register.js') }}"></script>
@endsection
