<?php
  $skin = get_color()->skin;
?>
@extends('layouts.frontend', ['skin' => $skin])

{{-- Page Title --}}
@section('page-title', 'Quên mật khẩu')
<!-- Main content -->
@section('content')

@if (session('status')) 
    <div class="alert alert-success mt-3" >
        Chúng tôi đã gửi đường dẫn đặt lại mật khẩu tới email của bạn. Nếu không nhận được email xin vui lòng gửi lại.
    </div>
@endif
<div class="login-box">
    <div class="card">
        <div class="card-body">
            <p class="box-msg">Xin vui lòng nhập email đã đăng ký </p>

            <form id="email-form" method="POST" action="{{ route('password.email') }}">
                {{ csrf_field() }}

                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="email" class="form-control-label">Email</label>
                            <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required autofocus>
                            @if ($errors->has('email'))
                                <div class="invalid-feedback">Email {{ $errors->first('email') }}</div>
                            @endif
                        </div>
                        <!-- /.form-group -->
                    </div>
                    <!-- col-md-12 -->
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <button type="submit" class="btn btn-{{ $skin }}">Gửi email</button>
                            <p class="float-right"><a href="{{ route('password.sms') }}"><button type="button" class="btn btn-outline-{{ $skin }}">Hoặc bằng sms</button></a></p>
                        </div>
                        <!-- /.form-group -->
                    </div>
                    <!-- col-md-12 -->
                </div>
                <!-- row -->
            </form>
            <!-- /form -->
            <p class="box-msg"><em>Nếu bạn còn nhớ mật khẩu thì hãy bấm vào <a href="{{ route('login') }}">đây</a> để đăng nhập hoặc <a href="{{ route('welcome') }}">quay về trang chủ</a></em></p>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<!-- /.login-box -->
@endsection