<?php
  $skin = get_color()->skin;
?>
@extends('layouts.frontend', ['skin' => $skin])

{{-- Page Title --}}
@section('page-title', 'Quên mật khẩu')
<!-- Main content -->
@section('content')
<div class="login-box">
    <div class="card">
        <div class="card-body">
            <p class="box-msg">Nếu bạn quên mật khẩu, xin vui lòng làm theo hướng dẫn bên dưới:</p>
            <p>1. Gửi tin nhắn đến <b>01667.269.284</b> từ số điện thoại đã đăng ký theo cú pháp <br> <b>BITMO MATKHAU SỐ_CMND_CỦA_BẠN</b></p>
            <p>2. Chờ chúng tôi gửi lại mật khẩu (có thể mất một khoảng thời gian dài)</p>
            <p>3. <a href="{{ route('dashboard::profile') }}">Đăng nhập và đổi lại mật khẩu</a></p>

            <p class="box-msg"><a href="{{ route('password.request') }}"><button type="button" class="btn btn-outline-{{ $skin }}">Hoặc bằng email</button></a></p>

            <p class="box-msg"><em>Nếu bạn còn nhớ mật khẩu thì hãy bấm vào <a href="{{ route('login') }}">đây</a> để đăng nhập hoặc <a href="{{ route('welcome') }}">quay về trang chủ</a></em></p>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<!-- /.login-box -->
@endsection